package com.zahid.worldclock

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvStatus = findViewById<TextView>(R.id.tvWeatherStatus)
        val btnRefresh = findViewById<Button>(R.id.btnRefreshAll)

        loadPreview(tvStatus)

        btnRefresh.setOnClickListener {
            Toast.makeText(this, "Updating Rahim Yar Khan Weather & Widgets...", Toast.LENGTH_SHORT).show()
            loadPreview(tvStatus)
            broadcastWidgetUpdates()
        }
    }

    private fun loadPreview(tvStatus: TextView) {
        CoroutineScope(Dispatchers.IO).launch {
            val weather = WeatherRepository.fetchRahimYarKhanWeather(this@MainActivity)
            withContext(Dispatchers.Main) {
                tvStatus.text = "Rahim Yar Khan\n${weather.temperature} | ${weather.condition}\nHumidity: ${weather.humidity}"
            }
        }
    }

    private fun broadcastWidgetUpdates() {
        val providers = listOf(
            WorldClockWidgetProvider::class.java,
            Widget1x1Provider::class.java,
            Widget2x2Provider::class.java,
            Widget4x4Provider::class.java
        )
        val manager = AppWidgetManager.getInstance(this)
        for (cls in providers) {
            val ids = manager.getAppWidgetIds(ComponentName(this, cls))
            if (ids.isNotEmpty()) {
                val intent = Intent(this, cls).apply {
                    action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                }
                sendBroadcast(intent)
            }
        }
    }
}
