package com.zahid.worldclock

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class WeatherData(
    val city: String,
    val temperature: String,
    val condition: String,
    val humidity: String,
    val highLow: String
)

object WeatherRepository {
    // Coordinates for Rahim Yar Khan, Pakistan: 28.4212 N, 70.2989 E
    private const val API_URL =
        "https://api.open-meteo.com/v1/forecast?latitude=28.4212&longitude=70.2989&current=temperature_2m,relative_humidity_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=Asia%2FKarachi"

    fun fetchRahimYarKhanWeather(context: Context): WeatherData {
        val prefs = context.getSharedPreferences("zahid_weather_prefs", Context.MODE_PRIVATE)
        return try {
            val url = URL(API_URL)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 6000
                requestMethod = "GET"
            }
            if (conn.responseCode == 200) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                val current = json.getJSONObject("current")
                val temp = current.getDouble("temperature_2m").toInt()
                val humidity = current.getInt("relative_humidity_2m")
                val code = current.getInt("weather_code")

                val daily = json.getJSONObject("daily")
                val maxTemp = daily.getJSONArray("temperature_2m_max").getDouble(0).toInt()
                val minTemp = daily.getJSONArray("temperature_2m_min").getDouble(0).toInt()

                val condText = mapWeatherCode(code)
                val data = WeatherData(
                    city = "Rahim Yar Khan",
                    temperature = "${temp}°C",
                    condition = condText,
                    humidity = "${humidity}%",
                    highLow = "H:${maxTemp}° L:${minTemp}°"
                )
                prefs.edit()
                    .putString("temp", data.temperature)
                    .putString("cond", data.condition)
                    .putString("hum", data.humidity)
                    .putString("hl", data.highLow)
                    .apply()
                data
            } else {
                getCached(prefs)
            }
        } catch (e: Exception) {
            getCached(prefs)
        }
    }

    private fun getCached(prefs: android.content.SharedPreferences): WeatherData {
        return WeatherData(
            city = "Rahim Yar Khan",
            temperature = prefs.getString("temp", "28°C") ?: "28°C",
            condition = prefs.getString("cond", "Clear Sky") ?: "Clear Sky",
            humidity = prefs.getString("hum", "42%") ?: "42%",
            highLow = prefs.getString("hl", "H:31° L:18°") ?: "H:31° L:18°"
        )
    }

    private fun mapWeatherCode(code: Int): String {
        return when (code) {
            0 -> "Clear Sky"
            1, 2, 3 -> "Partly Cloudy"
            45, 48 -> "Foggy"
            51, 53, 55, 61, 63, 65 -> "Rainy"
            80, 81, 82 -> "Showers"
            95, 96, 99 -> "Thunderstorm"
            else -> "Sunny"
        }
    }
}
