package com.zahid.worldclock

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class WorldClockWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH_WEATHER = "com.zahid.worldclock.ACTION_REFRESH_WEATHER"

        fun updateWidgetLayout(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int,
            layoutId: Int
        ) {
            val views = RemoteViews(context.packageName, layoutId)

            val pktZone = TimeZone.getTimeZone("Asia/Karachi")
            val dateFmt = SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).apply {
                timeZone = pktZone
            }
            val currentDate = dateFmt.format(Date())

            views.setTextViewText(R.id.tvCityName, "Rahim Yar Khan")
            views.setTextViewText(R.id.tvDateText, currentDate)

            val refreshIntent = Intent(context, WorldClockWidgetProvider::class.java).apply {
                action = ACTION_REFRESH_WEATHER
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                appWidgetId,
                refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)

            CoroutineScope(Dispatchers.IO).launch {
                val weather = WeatherRepository.fetchRahimYarKhanWeather(context)
                views.setTextViewText(R.id.tvTemperature, weather.temperature)
                views.setTextViewText(R.id.tvCondition, "${weather.condition} • ${weather.highLow}")
                appWidgetManager.updateAppWidget(appWidgetId, views)
            }
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            updateWidgetLayout(context, appWidgetManager, appWidgetId, R.layout.widget_4x2)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_TIME_SET,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            ACTION_REFRESH_WEATHER,
            AppWidgetManager.ACTION_APPWIDGET_UPDATE -> {
                val appWidgetManager = AppWidgetManager.getInstance(context)
                val ids = appWidgetManager.getAppWidgetIds(
                    ComponentName(context, WorldClockWidgetProvider::class.java)
                )
                onUpdate(context, appWidgetManager, ids)
            }
        }
    }
}
