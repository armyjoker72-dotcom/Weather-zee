package com.zahid.worldclock

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import androidx.core.content.res.ResourcesCompat
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

data class ClockTheme(
    val bezelStart: Int,
    val bezelEnd: Int,
    val dialCenter: Int,
    val dialEdge: Int,
    val numberColor: Int,
    val tickColor: Int,
    val hourHand: Int,
    val minHand: Int,
    val secHand: Int
)

class WorldClockWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH = "com.zahid.worldclock.ACTION_REFRESH"
        const val ACTION_AUTO_UPDATE = "com.zahid.worldclock.ACTION_AUTO_UPDATE"
        private val executor = Executors.newSingleThreadExecutor()

        private val URDU_DAYS = mapOf(
            Calendar.SUNDAY to "اتوار",
            Calendar.MONDAY to "سوموار",
            Calendar.TUESDAY to "منگل",
            Calendar.WEDNESDAY to "بدھ",
            Calendar.THURSDAY to "جمعرات",
            Calendar.FRIDAY to "جمعۃ المبارک",
            Calendar.SATURDAY to "ہفتہ"
        )

        private fun c(hex: String) = Color.parseColor(hex)

        private val CLOCK_THEMES = listOf(
            ClockTheme(c("#1E293B"), c("#000000"), c("#FFFFFF"), c("#F1F5F9"), c("#0F172A"), c("#475569"), c("#000000"), c("#1E293B"), c("#DC2626")),
            ClockTheme(c("#2563EB"), c("#1E3A8A"), c("#FFFFFF"), c("#DBEAFE"), c("#1E3A8A"), c("#3B82F6"), c("#1E3A8A"), c("#2563EB"), c("#EF4444")),
            ClockTheme(c("#FDE047"), c("#A16207"), c("#111827"), c("#000000"), c("#FACC15"), c("#CA8A04"), c("#FDE047"), c("#FEF08A"), c("#EF4444")),
            ClockTheme(c("#94A3B8"), c("#334155"), c("#1E293B"), c("#0F172A"), c("#F8FAFC"), c("#94A3B8"), c("#FFFFFF"), c("#CBD5E1"), c("#38BDF8")),
            ClockTheme(c("#FACC15"), c("#854D0E"), c("#065F46"), c("#022C22"), c("#FEF08A"), c("#6EE7B7"), c("#FDE047"), c("#FFFFFF"), c("#FB7185")),
            ClockTheme(c("#DC2626"), c("#7F1D1D"), c("#FFFFFF"), c("#FEE2E2"), c("#7F1D1D"), c("#B91C1C"), c("#7F1D1D"), c("#DC2626"), c("#000000")),
            ClockTheme(c("#0D9488"), c("#115E59"), c("#F0FDFA"), c("#CCFBF1"), c("#134E4A"), c("#0F766E"), c("#134E4A"), c("#0D9488"), c("#F97316")),
            ClockTheme(c("#FB923C"), c("#C2410C"), c("#1E293B"), c("#0F172A"), c("#FDBA74"), c("#FB923C"), c("#F97316"), c("#FFFFFF"), c("#FACC15")),
            ClockTheme(c("#C084FC"), c("#581C87"), c("#3B0764"), c("#1E1B4B"), c("#FDE047"), c("#D8B4FE"), c("#FACC15"), c("#FFFFFF"), c("#F472B6")),
            ClockTheme(c("#F9A8D4"), c("#BE185D"), c("#FFF1F2"), c("#FCE7F3"), c("#831843"), c("#BE185D"), c("#831843"), c("#DB2777"), c("#1E293B")),
            ClockTheme(c("#F8FAFC"), c("#64748B"), c("#E2E8F0"), c("#CBD5E1"), c("#0F172A"), c("#475569"), c("#0F172A"), c("#334155"), c("#DC2626")),
            ClockTheme(c("#22D3EE"), c("#0284C7"), c("#09090B"), c("#18181B"), c("#22D3EE"), c("#06B6D4"), c("#22D3EE"), c("#A855F7"), c("#F43F5E")),
            ClockTheme(c("#92400E"), c("#451A03"), c("#FEF3C7"), c("#FDE68A"), c("#451A03"), c("#78350F"), c("#451A03"), c("#78350F"), c("#DC2626")),
            ClockTheme(c("#EF4444"), c("#450A0A"), c("#18181B"), c("#09090B"), c("#FFFFFF"), c("#EF4444"), c("#FFFFFF"), c("#E5E7EB"), c("#EF4444")),
            ClockTheme(c("#1E3A8A"), c("#172554"), c("#E0F2FE"), c("#BAE6FD"), c("#0C4A6E"), c("#0369A1"), c("#0C4A6E"), c("#0284C7"), c("#DC2626")),
            ClockTheme(c("#15803D"), c("#14532D"), c("#F0FDF4"), c("#DCFCE7"), c("#14532D"), c("#166534"), c("#14532D"), c("#15803D"), c("#CA8A04")),
            ClockTheme(c("#D97706"), c("#78350F"), c("#292524"), c("#1C1917"), c("#FDE68A"), c("#D97706"), c("#FBBF24"), c("#FEF3C7"), c("#EF4444")),
            ClockTheme(c("#38BDF8"), c("#0369A1"), c("#334155"), c("#1E293B"), c("#E0F2FE"), c("#38BDF8"), c("#FFFFFF"), c("#7DD3FC"), c("#FACC15")),
            ClockTheme(c("#FACC15"), c("#A16207"), c("#881337"), c("#4C0519"), c("#FEF08A"), c("#FDA4AF"), c("#FDE047"), c("#FFFFFF"), c("#38BDF8")),
            ClockTheme(c("#7DD3FC"), c("#0284C7"), c("#FFFFFF"), c("#E0F2FE"), c("#0369A1"), c("#0284C7"), c("#0369A1"), c("#0EA5E9"), c("#F43F5E"))
        )

        fun scheduleAutoUpdate(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, WorldClockWidgetProvider::class.java).apply {
                action = ACTION_AUTO_UPDATE
            }
            val pi = PendingIntent.getBroadcast(
                context, 99, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val intervalMs = Prefs.getAutoUpdateMinutes(context) * 60_000L
            alarmManager.setInexactRepeating(
                AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + intervalMs,
                intervalMs,
                pi
            )
        }

        fun updateAllWidgets(context: Context, fetchWeather: Boolean = true) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, WorldClockWidgetProvider::class.java))
            if (ids.isEmpty()) return

            val cached = Prefs.getCachedWeather(context)
            for (id in ids) {
                renderWidget(context, manager, id, cached)
            }

            if (fetchWeather) {
                executor.execute {
                    val lat = Prefs.getWeatherLat(context)
                    val lon = Prefs.getWeatherLon(context)
                    val apiUrl = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                        "&current=temperature_2m,is_day,weather_code" +
                        "&daily=temperature_2m_max,temperature_2m_min" +
                        "&timezone=auto&forecast_days=1"
                    try {
                        val conn = URL(apiUrl).openConnection() as HttpURLConnection
                        conn.connectTimeout = 9000
                        conn.readTimeout = 9000
                        conn.requestMethod = "GET"
                        if (conn.responseCode == 200) {
                            val response = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                            Prefs.saveCachedWeather(context, response)
                            for (id in ids) {
                                renderWidget(context, manager, id, response)
                            }
                        }
                        conn.disconnect()
                    } catch (_: Exception) {
                    }
                }
            }
        }

        private fun isDaytimeNow(jsonStr: String?): Boolean {
            if (!jsonStr.isNullOrBlank()) {
                try {
                    val isDayFlag = JSONObject(jsonStr).getJSONObject("current").optInt("is_day", -1)
                    if (isDayFlag == 0 || isDayFlag == 1) return isDayFlag == 1
                } catch (_: Exception) {}
            }
            val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            return hour in 6..17
        }

        private fun mapWeatherCondition(code: Int): String = when (code) {
            0 -> "Clear"
            1 -> "Mainly Clear"
            2 -> "Partly Cloudy"
            3 -> "Cloudy"
            45, 48 -> "Foggy"
            51, 53, 55, 56, 57 -> "Drizzle"
            61, 63, 65, 66, 67, 80, 81, 82 -> "Rain"
            71, 73, 75, 77, 85, 86 -> "Snow"
            95, 96, 99 -> "Thunderstorm"
            else -> "Clear"
        }

        private fun darkenColor(color: Int, factor: Float): Int {
            val r = (Color.red(color) * factor).roundToInt().coerceIn(0, 255)
            val g = (Color.green(color) * factor).roundToInt().coerceIn(0, 255)
            val b = (Color.blue(color) * factor).roundToInt().coerceIn(0, 255)
            return Color.argb(Color.alpha(color), r, g, b)
        }

        private fun renderStyledText(
            context: Context,
            mainText: String,
            suffixSmall: String?,
            mainSizeSp: Float,
            suffixSizeSp: Float,
            fillColor: Int,
            borderColor: Int,
            borderOn: Boolean,
            enable3D: Boolean,
            customTypeface: Typeface?
        ): Bitmap {
            val dm = context.resources.displayMetrics
            val mainPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, mainSizeSp, dm)
            val smallPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, suffixSizeSp, dm)
            val strokePx = if (borderOn) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 2.2f, dm) else 0f
            val depthPx = if (enable3D) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 2.8f, dm) else 0f

            val tf = customTypeface ?: Typeface.create(Typeface.SERIF, Typeface.BOLD)
            val mainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = mainPx; typeface = tf; isSubpixelText = true
            }
            val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = smallPx; typeface = tf; isSubpixelText = true
            }

            val wMain = mainPaint.measureText(mainText)
            val wSmall = if (suffixSmall != null) smallPaint.measureText(suffixSmall) else 0f
            val fm = mainPaint.fontMetrics
            val pad = ceil(strokePx + 6f).toInt()
            val extra3D = ceil(depthPx).toInt()

            val bmpW = (ceil(wMain + wSmall).toInt() + pad * 2 + extra3D).coerceAtLeast(24)
            val bmpH = (ceil(fm.descent - fm.ascent).toInt() + pad * 2 + extra3D).coerceAtLeast(24)

            val bmp = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val x = pad.toFloat()
            val y = pad.toFloat() - fm.ascent

            fun drawPart(txt: String, p: Paint, drawX: Float) {
                if (enable3D && extra3D > 0) {
                    val base3D = if (borderOn) borderColor else darkenColor(fillColor, 0.35f)
                    for (step in 4 downTo 1) {
                        val ratio = step / 4f
                        val off = depthPx * ratio
                        p.style = Paint.Style.FILL
                        p.color = darkenColor(base3D, 0.85f - 0.45f * ratio)
                        canvas.drawText(txt, drawX + off, y + off, p)
                    }
                }
                if (borderOn && strokePx > 0f) {
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = strokePx
                    p.strokeJoin = Paint.Join.ROUND
                    p.strokeCap = Paint.Cap.ROUND
                    p.color = borderColor
                    canvas.drawText(txt, drawX, y, p)
                }
                p.style = Paint.Style.FILL
                p.color = fillColor
                canvas.drawText(txt, drawX, y, p)
            }

            drawPart(mainText, mainPaint, x)
            if (suffixSmall != null) drawPart(suffixSmall, smallPaint, x + wMain)
            return bmp
        }

        // Clean Analog Clock: NO text/country/date inside the dial!
        private fun renderCleanAnalogClock(timeZoneId: String, designIdx: Int): Bitmap {
            val size = 260
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            val cx = size / 2f
            val cy = size / 2f
            val r = (size / 2f) - 12f

            val theme = CLOCK_THEMES[designIdx.coerceIn(0, CLOCK_THEMES.lastIndex)]
            val cal = Calendar.getInstance(TimeZone.getTimeZone(timeZoneId))
            val hour = cal.get(Calendar.HOUR_OF_DAY)
            val minute = cal.get(Calendar.MINUTE)
            val second = cal.get(Calendar.SECOND)

            val paint = Paint(Paint.ANTI_ALIAS_FLAG)

            paint.style = Paint.Style.FILL
            paint.shader = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(), theme.bezelStart, theme.bezelEnd, Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, r + 9f, paint)

            paint.shader = RadialGradient(cx, cy - 18f, r, theme.dialCenter, theme.dialEdge, Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, r, paint)
            paint.shader = null

            for (i in 0 until 60) {
                val ang = Math.toRadians(i * 6.0)
                val isHour = i % 5 == 0
                val inner = if (isHour) r - 15f else r - 8f
                paint.color = if (isHour) theme.numberColor else theme.tickColor
                paint.strokeWidth = if (isHour) 3.4f else 1.5f
                paint.style = Paint.Style.STROKE
                canvas.drawLine(
                    (cx + sin(ang) * inner).toFloat(), (cy - cos(ang) * inner).toFloat(),
                    (cx + sin(ang) * (r - 2f)).toFloat(), (cy - cos(ang) * (r - 2f)).toFloat(),
                    paint
                )
            }

            paint.style = Paint.Style.FILL
            paint.color = theme.numberColor
            paint.textSize = 23f
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            val textOffset = (paint.descent() + paint.ascent()) / 2f
            for (num in 1..12) {
                val ang = Math.toRadians(num * 30.0)
                val nx = (cx + sin(ang) * (r - 32f)).toFloat()
                val ny = (cy - cos(ang) * (r - 32f)).toFloat() - textOffset
                canvas.drawText(num.toString(), nx, ny, paint)
            }

            fun drawHand(angleDeg: Double, length: Float, width: Float, color: Int) {
                val rad = Math.toRadians(angleDeg)
                paint.style = Paint.Style.STROKE
                paint.strokeCap = Paint.Cap.ROUND
                paint.strokeWidth = width
                paint.color = color
                canvas.drawLine(cx, cy, (cx + sin(rad) * length).toFloat(), (cy - cos(rad) * length).toFloat(), paint)
            }

            drawHand(((hour % 12) + minute / 60.0) * 30.0, r * 0.48f, 7.5f, theme.hourHand)
            drawHand((minute + second / 60.0) * 6.0, r * 0.70f, 5.0f, theme.minHand)
            drawHand(second * 6.0, r * 0.80f, 2.5f, theme.secHand)

            paint.style = Paint.Style.FILL
            paint.color = theme.secHand
            canvas.drawCircle(cx, cy, 7f, paint)

            return bmp
        }

        private fun renderWidget(context: Context, manager: AppWidgetManager, appWidgetId: Int, jsonStr: String?) {
            val views = RemoteViews(context.packageName, R.layout.widget_world_clock)

            val openPi = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, openPi)



            val isDay = isDaytimeNow(jsonStr)
            if (Prefs.isTransparent(context)) {
                views.setViewVisibility(R.id.bg_image, View.GONE)
            } else {
                views.setViewVisibility(R.id.bg_image, View.VISIBLE)
                views.setImageViewResource(R.id.bg_image, if (isDay) R.drawable.bg_day else R.drawable.bg_night)
            }

            val autoColor = Prefs.isAutoDayNightColor(context)
            val autoTextColor = if (isDay) Color.BLACK else Color.WHITE
            val autoBorderColor = if (isDay) Color.WHITE else Color.BLACK

            val clockColor = if (autoColor) autoTextColor else Prefs.getClockColor(context)
            val dateColor = if (autoColor) autoTextColor else Prefs.getDateColor(context)
            val dayColor = if (autoColor) autoTextColor else Prefs.getDayColor(context)
            val borderColor = if (autoColor) autoBorderColor else Prefs.getBorderColor(context)
            val borderOn = Prefs.isBorderEnabled(context)

            val fontIdx = Prefs.getFontIdx(context)
            val is3D = Prefs.is3DFont(fontIdx)
            val customTf = ResourcesCompat.getFont(context, Prefs.FONT_RES_IDS[fontIdx])

            // 1. Live Digital Clock with custom size
            val hour12 = Prefs.isHour12(context)
            val fmt = if (hour12) "hh:mm:ss a" else "HH:mm:ss"
            val clockSize = Prefs.getClockSize(context)
            views.removeAllViews(R.id.clock_container)
            val clockViews = RemoteViews(context.packageName, Prefs.CLOCK_LAYOUT_RES_IDS[fontIdx])

            fun styleClockLayer(viewId: Int, col: Int, vis: Boolean) {
                clockViews.setViewVisibility(viewId, if (vis) View.VISIBLE else View.GONE)
                if (vis) {
                    clockViews.setCharSequence(viewId, "setFormat12Hour", fmt)
                    clockViews.setCharSequence(viewId, "setFormat24Hour", fmt)
                    clockViews.setTextViewTextSize(viewId, TypedValue.COMPLEX_UNIT_SP, clockSize)
                    clockViews.setTextColor(viewId, col)
                }
            }
            styleClockLayer(R.id.clock_main, clockColor, true)
            styleClockLayer(R.id.clock_b1, borderColor, borderOn)
            styleClockLayer(R.id.clock_b2, borderColor, borderOn)
            styleClockLayer(R.id.clock_b3, borderColor, borderOn)
            styleClockLayer(R.id.clock_b4, borderColor, borderOn)
            if (is3D) {
                val base3D = if (borderOn) borderColor else darkenColor(clockColor, 0.40f)
                styleClockLayer(R.id.clock_3d_1, darkenColor(base3D, 0.85f), true)
                styleClockLayer(R.id.clock_3d_2, darkenColor(base3D, 0.68f), true)
                styleClockLayer(R.id.clock_3d_3, darkenColor(base3D, 0.52f), true)
                styleClockLayer(R.id.clock_3d_4, darkenColor(base3D, 0.36f), true)
            }
            views.addView(R.id.clock_container, clockViews)

            // 2. Date + Custom-size Month-End (31)
            val cal = Calendar.getInstance()
            val dayNum = cal.get(Calendar.DAY_OF_MONTH)
            val monthName = SimpleDateFormat("MMMM", Locale.US).format(cal.time)
            val year = cal.get(Calendar.YEAR)
            val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            views.setImageViewBitmap(
                R.id.date_img,
                renderStyledText(
                    context, "$dayNum $monthName $year ", "($daysInMonth)",
                    Prefs.getDateSize(context), Prefs.getMonthEndSize(context),
                    dateColor, borderColor, borderOn, is3D, customTf
                )
            )

            // 3. Day in English + Full Urdu (جمعۃ المبارک)
            val engDay = SimpleDateFormat("EEEE", Locale.US).format(cal.time)
            val urduDay = URDU_DAYS[cal.get(Calendar.DAY_OF_WEEK)] ?: ""
            views.setImageViewBitmap(
                R.id.day_img,
                renderStyledText(
                    context, "$engDay   $urduDay", null,
                    Prefs.getDaySize(context), Prefs.getDaySize(context),
                    dayColor, borderColor, borderOn, is3D, null
                )
            )

            // 4. Live Weather Side Block (Left Side)
            val weatherColor = if (isDay) Color.BLACK else Color.WHITE
            views.setTextColor(R.id.weather_temp, weatherColor)
            views.setTextColor(R.id.weather_cond, weatherColor)
            views.setTextColor(R.id.weather_range, weatherColor)
            if (!jsonStr.isNullOrBlank()) {
                try {
                    val root = JSONObject(jsonStr)
                    val cur = root.getJSONObject("current")
                    val curTemp = cur.getDouble("temperature_2m").roundToInt()
                    val cond = mapWeatherCondition(cur.optInt("weather_code", 0))
                    val daily = root.getJSONObject("daily")
                    val lo = daily.getJSONArray("temperature_2m_min").getDouble(0).roundToInt()
                    val hi = daily.getJSONArray("temperature_2m_max").getDouble(0).roundToInt()
                    views.setTextViewText(R.id.weather_temp, "${curTemp}°")
                    views.setTextViewText(R.id.weather_cond, cond)
                    views.setTextViewText(R.id.weather_range, "L:${lo}° ~ H:${hi}°")
                } catch (_: Exception) {}
            }

            // 5. 3 Clean Analog Clocks with Independent Hide/Show
            val hide1 = Prefs.isHideClock1(context)
            val hide2 = Prefs.isHideClock2(context)
            val hide3 = Prefs.isHideClock3(context)
            val designIdx = Prefs.getClockDesignIdx(context)
            val labelColor = if (isDay) Color.BLACK else Color.WHITE

            views.setViewVisibility(R.id.clock_box_1, if (hide1) View.GONE else View.VISIBLE)
            views.setViewVisibility(R.id.clock_box_2, if (hide2) View.GONE else View.VISIBLE)
            views.setViewVisibility(R.id.clock_box_3, if (hide3) View.GONE else View.VISIBLE)

            if (!hide1) {
                val c1 = Prefs.COUNTRIES[Prefs.getClock1Idx(context)]
                views.setTextViewText(R.id.label_clock_1, c1.label)
                views.setTextColor(R.id.label_clock_1, labelColor)
                views.setImageViewBitmap(R.id.clock_1, renderCleanAnalogClock(c1.tzId, designIdx))
            }
            if (!hide2) {
                val c2 = Prefs.COUNTRIES[Prefs.getClock2Idx(context)]
                views.setTextViewText(R.id.label_clock_2, c2.label)
                views.setTextColor(R.id.label_clock_2, labelColor)
                views.setImageViewBitmap(R.id.clock_2, renderCleanAnalogClock(c2.tzId, designIdx))
            }
            if (!hide3) {
                val c3 = Prefs.COUNTRIES[Prefs.getClock3Idx(context)]
                views.setTextViewText(R.id.label_clock_3, c3.label)
                views.setTextColor(R.id.label_clock_3, labelColor)
                views.setImageViewBitmap(R.id.clock_3, renderCleanAnalogClock(c3.tzId, designIdx))
            }

            manager.updateAppWidget(appWidgetId, views)
        }
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        scheduleAutoUpdate(context)
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        updateAllWidgets(context, fetchWeather = true)
        scheduleAutoUpdate(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_REFRESH,
            ACTION_AUTO_UPDATE,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_SET,
            Intent.ACTION_TIMEZONE_CHANGED -> updateAllWidgets(context, fetchWeather = true)
        }
    }
}
