package com.zahid.worldclock

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private val executor = Executors.newSingleThreadExecutor()

    private val presetColors = intArrayOf(
        0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFFACC15.toInt(), 0xFFEF4444.toInt(),
        0xFF1D4ED8.toInt(), 0xFF38BDF8.toInt(), 0xFF22C55E.toInt(), 0xFFFB923C.toInt(),
        0xFFF472B6.toInt(), 0xFFA855F7.toInt(), 0xFFCBD5E1.toInt(), 0xFF78350F.toInt()
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnPin = findViewById<Button>(R.id.btnPinWidget)
        val btnRefresh = findViewById<Button>(R.id.btnRefreshNow)
        val tvWeatherCity = findViewById<TextView>(R.id.tvWeatherCity)
        val etCitySearch = findViewById<EditText>(R.id.etCitySearch)
        val btnSearchCity = findViewById<Button>(R.id.btnSearchCity)
        val tvCityStatus = findViewById<TextView>(R.id.tvCityStatus)
        val spAutoUpdate = findViewById<Spinner>(R.id.spAutoUpdate)

        val cbHide1 = findViewById<CheckBox>(R.id.cbHideClock1)
        val cbHide2 = findViewById<CheckBox>(R.id.cbHideClock2)
        val cbHide3 = findViewById<CheckBox>(R.id.cbHideClock3)
        val spClock1 = findViewById<Spinner>(R.id.spClock1Country)
        val spClock2 = findViewById<Spinner>(R.id.spClock2Country)
        val spClock3 = findViewById<Spinner>(R.id.spClock3Country)

        val spDesign = findViewById<Spinner>(R.id.spClockDesign)
        val spFont = findViewById<Spinner>(R.id.spTextFont)
        val swAutoColor = findViewById<SwitchMaterial>(R.id.swAutoDayNightColor)
        val swBorder = findViewById<SwitchMaterial>(R.id.swBorder)
        val swHour12 = findViewById<SwitchMaterial>(R.id.swHour12)
        val swTransparent = findViewById<SwitchMaterial>(R.id.swTransparent)
        val btnReset = findViewById<Button>(R.id.btnReset)

        fun updateCityLabel() {
            val c = Prefs.getWeatherCity(this)
            val country = Prefs.getWeatherCountry(this)
            tvWeatherCity.text = if (country.isNotBlank()) "$c, $country" else c
        }
        updateCityLabel()

        btnPin.setOnClickListener {
            val mgr = AppWidgetManager.getInstance(this)
            val provider = ComponentName(this, WorldClockWidgetProvider::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(provider, null, null)
            } else {
                Toast.makeText(this, "Long-press Home Screen -> Widgets -> Zahid World Clock", Toast.LENGTH_LONG).show()
            }
        }

        btnRefresh.setOnClickListener {
            WorldClockWidgetProvider.updateAllWidgets(this, fetchWeather = true)
            WorldClockWidgetProvider.scheduleAutoUpdate(this)
            Toast.makeText(this, "Refreshing live weather & clocks...", Toast.LENGTH_SHORT).show()
        }

        btnSearchCity.setOnClickListener {
            val query = etCitySearch.text.toString().trim()
            if (query.length < 2) {
                tvCityStatus.text = "Please enter a valid city name."
                return@setOnClickListener
            }
            tvCityStatus.text = "Searching $query..."
            executor.execute {
                try {
                    val encoded = URLEncoder.encode(query, "UTF-8")
                    val url = "https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=en&format=json"
                    val conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = 8000
                    conn.readTimeout = 8000
                    val text = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                    conn.disconnect()

                    val results = JSONObject(text).optJSONArray("results")
                    if (results != null && results.length() > 0) {
                        val first = results.getJSONObject(0)
                        val name = first.getString("name")
                        val country = first.optString("country", "")
                        val lat = first.getDouble("latitude")
                        val lon = first.getDouble("longitude")
                        Prefs.setWeatherCity(this, name, country, lat, lon)
                        runOnUiThread {
                            updateCityLabel()
                            etCitySearch.setText("")
                            tvCityStatus.text = "Weather city set to $name!"
                            WorldClockWidgetProvider.updateAllWidgets(this, fetchWeather = true)
                        }
                    } else {
                        runOnUiThread { tvCityStatus.text = "City not found." }
                    }
                } catch (_: Exception) {
                    runOnUiThread { tvCityStatus.text = "Network error. Check internet." }
                }
            }
        }

        fun bindSpinner(sp: Spinner, items: List<String>, initial: Int, onPick: (Int) -> Unit) {
            sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
            sp.setSelection(initial, false)
            sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    onPick(pos)
                    WorldClockWidgetProvider.updateAllWidgets(this@MainActivity, fetchWeather = false)
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }

        bindSpinner(spAutoUpdate, Prefs.AUTO_UPDATE_LABELS, Prefs.getAutoUpdateIdx(this)) {
            Prefs.setAutoUpdateIdx(this, it)
            WorldClockWidgetProvider.scheduleAutoUpdate(this)
        }

        // Hide / Unhide Clocks
        cbHide1.isChecked = Prefs.isHideClock1(this)
        cbHide1.setOnCheckedChangeListener { _, checked ->
            Prefs.setHideClock1(this, checked)
            WorldClockWidgetProvider.updateAllWidgets(this, fetchWeather = false)
        }
        cbHide2.isChecked = Prefs.isHideClock2(this)
        cbHide2.setOnCheckedChangeListener { _, checked ->
            Prefs.setHideClock2(this, checked)
            WorldClockWidgetProvider.updateAllWidgets(this, fetchWeather = false)
        }
        cbHide3.isChecked = Prefs.isHideClock3(this)
        cbHide3.setOnCheckedChangeListener { _, checked ->
            Prefs.setHideClock3(this, checked)
            WorldClockWidgetProvider.updateAllWidgets(this, fetchWeather = false)
        }

        bindSpinner(spClock1, Prefs.COUNTRY_NAMES, Prefs.getClock1Idx(this)) { Prefs.setClock1Idx(this, it) }
        bindSpinner(spClock2, Prefs.COUNTRY_NAMES, Prefs.getClock2Idx(this)) { Prefs.setClock2Idx(this, it) }
        bindSpinner(spClock3, Prefs.COUNTRY_NAMES, Prefs.getClock3Idx(this)) { Prefs.setClock3Idx(this, it) }
        bindSpinner(spDesign, Prefs.CLOCK_DESIGN_LABELS, Prefs.getClockDesignIdx(this)) { Prefs.setClockDesignIdx(this, it) }
        bindSpinner(spFont, Prefs.FONT_LABELS, Prefs.getFontIdx(this)) { Prefs.setFontIdx(this, it) }

        // Font Size Controls
        val syncSizes = mutableListOf<() -> Unit>()
        fun bindSize(tvId: Int, sbId: Int, minusId: Int, plusId: Int, label: String, minSp: Int, maxSp: Int, getter: () -> Float, setter: (Float) -> Unit) {
            val tv = findViewById<TextView>(tvId)
            val sb = findViewById<SeekBar>(sbId)
            val btnM = findViewById<Button>(minusId)
            val btnP = findViewById<Button>(plusId)
            sb.max = maxSp - minSp

            fun sync() {
                val cur = getter().roundToInt().coerceIn(minSp, maxSp)
                tv.text = "$label: $cur sp"
                sb.progress = cur - minSp
            }
            sync()
            syncSizes.add { sync() }

            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = minSp + p
                    tv.text = "$label: $v sp"
                    if (fromUser) {
                        setter(v.toFloat())
                        WorldClockWidgetProvider.updateAllWidgets(this@MainActivity, fetchWeather = false)
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            btnM.setOnClickListener {
                val next = (getter().roundToInt() - 1).coerceIn(minSp, maxSp)
                setter(next.toFloat()); sync()
                WorldClockWidgetProvider.updateAllWidgets(this@MainActivity, fetchWeather = false)
            }
            btnP.setOnClickListener {
                val next = (getter().roundToInt() + 1).coerceIn(minSp, maxSp)
                setter(next.toFloat()); sync()
                WorldClockWidgetProvider.updateAllWidgets(this@MainActivity, fetchWeather = false)
            }
        }

        bindSize(R.id.tvSizeClock, R.id.sbClock, R.id.btnMinusClock, R.id.btnPlusClock,
            "Top Time Size", 22, 64, { Prefs.getClockSize(this) }, { Prefs.setClockSize(this, it) })
        bindSize(R.id.tvSizeDate, R.id.sbDate, R.id.btnMinusDate, R.id.btnPlusDate,
            "Date Size", 12, 34, { Prefs.getDateSize(this) }, { Prefs.setDateSize(this, it) })
        bindSize(R.id.tvSizeMonthEnd, R.id.sbMonthEnd, R.id.btnMinusMonthEnd, R.id.btnPlusMonthEnd,
            "Month-End (31) Size", 8, 26, { Prefs.getMonthEndSize(this) }, { Prefs.setMonthEndSize(this, it) })
        bindSize(R.id.tvSizeDay, R.id.sbDay, R.id.btnMinusDay, R.id.btnPlusDay,
            "Day Size", 12, 34, { Prefs.getDaySize(this) }, { Prefs.setDaySize(this, it) })

        // Switches
        swAutoColor.isChecked = Prefs.isAutoDayNightColor(this)
        swAutoColor.setOnCheckedChangeListener { _, checked ->
            Prefs.setAutoDayNightColor(this, checked)
            WorldClockWidgetProvider.updateAllWidgets(this, fetchWeather = false)
        }
        swBorder.isChecked = Prefs.isBorderEnabled(this)
        swBorder.setOnCheckedChangeListener { _, checked ->
            Prefs.setBorderEnabled(this, checked)
            WorldClockWidgetProvider.updateAllWidgets(this, fetchWeather = false)
        }
        swHour12.isChecked = Prefs.isHour12(this)
        swHour12.setOnCheckedChangeListener { _, checked ->
            Prefs.setHour12(this, checked)
            WorldClockWidgetProvider.updateAllWidgets(this, fetchWeather = false)
        }
        swTransparent.isChecked = Prefs.isTransparent(this)
        swTransparent.setOnCheckedChangeListener { _, checked ->
            Prefs.setTransparent(this, checked)
            WorldClockWidgetProvider.updateAllWidgets(this, fetchWeather = false)
        }

        // Color Pickers
        val syncSwatches = mutableListOf<() -> Unit>()
        fun bindColor(btnId: Int, swatchId: Int, title: String, getter: () -> Int, setter: (Int) -> Unit) {
            val btn = findViewById<Button>(btnId)
            val swatch = findViewById<View>(swatchId)
            fun sync() {
                swatch.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(getter())
                    setStroke(3, Color.parseColor("#94A3B8"))
                }
            }
            sync()
            syncSwatches.add { sync() }
            val click = View.OnClickListener {
                showColorPickerDialog(title, getter()) { chosen ->
                    setter(chosen); sync()
                    WorldClockWidgetProvider.updateAllWidgets(this@MainActivity, fetchWeather = false)
                }
            }
            btn.setOnClickListener(click)
            swatch.setOnClickListener(click)
        }

        bindColor(R.id.btnColorClock, R.id.swatchClock, "Clock Time Color", { Prefs.getClockColor(this) }, { Prefs.setClockColor(this, it) })
        bindColor(R.id.btnColorDate, R.id.swatchDate, "Date Color", { Prefs.getDateColor(this) }, { Prefs.setDateColor(this, it) })
        bindColor(R.id.btnColorDay, R.id.swatchDay, "Day Color", { Prefs.getDayColor(this) }, { Prefs.setDayColor(this, it) })
        bindColor(R.id.btnColorBorder, R.id.swatchBorder, "Font Border Color", { Prefs.getBorderColor(this) }, { Prefs.setBorderColor(this, it) })

        btnReset.setOnClickListener {
            Prefs.resetAll(this)
            updateCityLabel()
            spAutoUpdate.setSelection(0)
            cbHide1.isChecked = false
            cbHide2.isChecked = false
            cbHide3.isChecked = false
            spClock1.setSelection(0)
            spClock2.setSelection(1)
            spClock3.setSelection(2)
            spDesign.setSelection(0)
            spFont.setSelection(0)
            swAutoColor.isChecked = true
            swBorder.isChecked = true
            swHour12.isChecked = false
            swTransparent.isChecked = false
            syncSizes.forEach { it() }
            syncSwatches.forEach { it() }
            WorldClockWidgetProvider.updateAllWidgets(this, fetchWeather = true)
            WorldClockWidgetProvider.scheduleAutoUpdate(this)
            Toast.makeText(this, "All settings reset to default", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showColorPickerDialog(title: String, initialColor: Int, onPicked: (Int) -> Unit) {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).roundToInt()

        var r = Color.red(initialColor)
        var g = Color.green(initialColor)
        var b = Color.blue(initialColor)

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(8))
        }

        val preview = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 15f
            setPadding(dp(12), dp(14), dp(12), dp(14))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(12) }
        }
        container.addView(preview)

        lateinit var sbR: SeekBar
        lateinit var sbG: SeekBar
        lateinit var sbB: SeekBar
        lateinit var tvR: TextView
        lateinit var tvG: TextView
        lateinit var tvB: TextView

        fun updatePreview() {
            val c = Color.rgb(r, g, b)
            preview.background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(c)
                setStroke(dp(1), Color.GRAY)
            }
            preview.text = String.format("#%02X%02X%02X", r, g, b)
            val lum = 0.299 * r + 0.587 * g + 0.114 * b
            preview.setTextColor(if (lum > 140) Color.BLACK else Color.WHITE)
            tvR.text = "Red: $r"
            tvG.text = "Green: $g"
            tvB.text = "Blue: $b"
        }

        for (rowIdx in 0..1) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(10) }
            }
            for (colIdx in 0..5) {
                val col = presetColors[rowIdx * 6 + colIdx]
                val swatch = View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply {
                        marginEnd = if (colIdx < 5) dp(8) else 0
                    }
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(col)
                        setStroke(dp(2), Color.parseColor("#94A3B8"))
                    }
                    setOnClickListener {
                        r = Color.red(col); g = Color.green(col); b = Color.blue(col)
                        sbR.progress = r; sbG.progress = g; sbB.progress = b
                        updatePreview()
                    }
                }
                row.addView(swatch)
            }
            container.addView(row)
        }

        fun addSlider(label: String, initVal: Int, onChange: (Int) -> Unit): Pair<TextView, SeekBar> {
            val tv = TextView(this).apply { text = "$label: $initVal"; textSize = 13f }
            val sb = SeekBar(this).apply {
                max = 255; progress = initVal
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        if (fromUser) { onChange(p); updatePreview() }
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            container.addView(tv); container.addView(sb)
            return Pair(tv, sb)
        }

        val pR = addSlider("Red", r) { r = it }
        val pG = addSlider("Green", g) { g = it }
        val pB = addSlider("Blue", b) { b = it }
        tvR = pR.first; sbR = pR.second
        tvG = pG.first; sbG = pG.second
        tvB = pB.first; sbB = pB.second
        updatePreview()

        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(container)
            .setPositiveButton("Apply") { _, _ -> onPicked(Color.rgb(r, g, b)) }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
