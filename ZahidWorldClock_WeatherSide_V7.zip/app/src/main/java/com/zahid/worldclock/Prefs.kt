package com.zahid.worldclock

import android.content.Context

data class CountryZone(val label: String, val tzId: String)

object Prefs {
    private const val PREF_NAME = "zahid_worldclock_v5_prefs"

    const val DEFAULT_CITY = "Rahim Yar Khan"
    const val DEFAULT_COUNTRY = "Pakistan"
    const val DEFAULT_LAT = 28.4212
    const val DEFAULT_LON = 70.2989

    const val DEFAULT_CLOCK_SIZE = 38f
    const val DEFAULT_DATE_SIZE = 20f
    const val DEFAULT_MONTH_END_SIZE = 12f
    const val DEFAULT_DAY_SIZE = 20f

    val AUTO_UPDATE_LABELS = listOf(
        "Every 5 Minutes (Recommended)",
        "Every 3 Minutes",
        "Every 15 Minutes"
    )
    val AUTO_UPDATE_MINUTES = intArrayOf(5, 3, 15)

    val COUNTRIES = listOf(
        CountryZone("Dubai", "Asia/Dubai"),
        CountryZone("Saudi Arabia", "Asia/Riyadh"),
        CountryZone("Kuwait", "Asia/Kuwait"),
        CountryZone("Pakistan", "Asia/Karachi"),
        CountryZone("Qatar", "Asia/Qatar"),
        CountryZone("Oman", "Asia/Muscat"),
        CountryZone("Bahrain", "Asia/Bahrain"),
        CountryZone("United Kingdom", "Europe/London"),
        CountryZone("USA (New York)", "America/New_York"),
        CountryZone("USA (Los Angeles)", "America/Los_Angeles"),
        CountryZone("Canada (Toronto)", "America/Toronto"),
        CountryZone("Turkey", "Europe/Istanbul"),
        CountryZone("Malaysia", "Asia/Kuala_Lumpur"),
        CountryZone("Singapore", "Asia/Singapore"),
        CountryZone("Australia (Sydney)", "Australia/Sydney"),
        CountryZone("Japan", "Asia/Tokyo"),
        CountryZone("China", "Asia/Shanghai"),
        CountryZone("Germany", "Europe/Berlin"),
        CountryZone("France", "Europe/Paris"),
        CountryZone("Italy", "Europe/Rome"),
        CountryZone("Spain", "Europe/Madrid"),
        CountryZone("India", "Asia/Kolkata"),
        CountryZone("Egypt", "Africa/Cairo"),
        CountryZone("South Africa", "Africa/Johannesburg"),
        CountryZone("New Zealand", "Pacific/Auckland")
    )

    val COUNTRY_NAMES: List<String> = COUNTRIES.map { it.label }

    val CLOCK_DESIGN_LABELS = listOf(
        "1. Classic White & Black",
        "2. Royal Blue & White",
        "3. Luxury Gold & Black",
        "4. Midnight Dark & Silver",
        "5. Emerald Green & Gold",
        "6. Crimson Red & White",
        "7. Ocean Teal & White",
        "8. Sunset Orange & Navy",
        "9. Royal Purple & Gold",
        "10. Rose Gold & Pearl",
        "11. Silver Metallic",
        "12. Neon Cyber Dark",
        "13. Vintage Cream & Brown",
        "14. Carbon Black & Red",
        "15. Sky Blue & Navy",
        "16. Forest Green & Cream",
        "17. Chocolate Bronze & Gold",
        "18. Slate Grey & Cyan",
        "19. Ruby Wine & Gold",
        "20. Arctic Ice & Blue"
    )

    val FONT_LABELS = listOf(
        "1. Lato Black (Modern Bold)",
        "2. Lato Heavy Italic",
        "3. DejaVu Sans Bold",
        "4. DejaVu Sans Condensed",
        "5. DejaVu Serif Bold",
        "6. DejaVu Serif Condensed",
        "7. DejaVu Mono (Digital)",
        "8. Liberation Mono Bold",
        "9. Liberation Narrow Bold",
        "10. Liberation Serif Bold",
        "11. URW Gothic (Geometric)",
        "12. URW Bookman (Classic)",
        "13. Palatino Bold (Luxury)",
        "14. Century Bold",
        "15. Chancery Stylish Italic",
        "16. [3D] Block Bold 3D",
        "17. [3D] Slanted Heavy 3D",
        "18. [3D] Digital Cyber 3D",
        "19. [3D] Geometric Pop 3D",
        "20. [3D] Luxury Serif 3D"
    )

    val FONT_RES_IDS = intArrayOf(
        R.font.font_01, R.font.font_02, R.font.font_03, R.font.font_04, R.font.font_05,
        R.font.font_06, R.font.font_07, R.font.font_08, R.font.font_09, R.font.font_10,
        R.font.font_11, R.font.font_12, R.font.font_13, R.font.font_14, R.font.font_15,
        R.font.font_01, R.font.font_02, R.font.font_07, R.font.font_11, R.font.font_13
    )

    val CLOCK_LAYOUT_RES_IDS = intArrayOf(
        R.layout.clock_style_00, R.layout.clock_style_01, R.layout.clock_style_02, R.layout.clock_style_03, R.layout.clock_style_04,
        R.layout.clock_style_05, R.layout.clock_style_06, R.layout.clock_style_07, R.layout.clock_style_08, R.layout.clock_style_09,
        R.layout.clock_style_10, R.layout.clock_style_11, R.layout.clock_style_12, R.layout.clock_style_13, R.layout.clock_style_14,
        R.layout.clock_style_15, R.layout.clock_style_16, R.layout.clock_style_17, R.layout.clock_style_18, R.layout.clock_style_19
    )

    fun is3DFont(index: Int): Boolean = index >= 15

    private fun sp(ctx: Context) = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    // Weather City & Cache
    fun getWeatherCity(ctx: Context): String = sp(ctx).getString("w_city", DEFAULT_CITY) ?: DEFAULT_CITY
    fun getWeatherCountry(ctx: Context): String = sp(ctx).getString("w_country", DEFAULT_COUNTRY) ?: DEFAULT_COUNTRY
    fun getWeatherLat(ctx: Context): Double = java.lang.Double.longBitsToDouble(
        sp(ctx).getLong("w_lat", java.lang.Double.doubleToRawLongBits(DEFAULT_LAT))
    )
    fun getWeatherLon(ctx: Context): Double = java.lang.Double.longBitsToDouble(
        sp(ctx).getLong("w_lon", java.lang.Double.doubleToRawLongBits(DEFAULT_LON))
    )
    fun setWeatherCity(ctx: Context, name: String, country: String, lat: Double, lon: Double) {
        sp(ctx).edit()
            .putString("w_city", name)
            .putString("w_country", country)
            .putLong("w_lat", java.lang.Double.doubleToRawLongBits(lat))
            .putLong("w_lon", java.lang.Double.doubleToRawLongBits(lon))
            .apply()
    }
    fun saveCachedWeather(ctx: Context, json: String) = sp(ctx).edit().putString("w_cache", json).apply()
    fun getCachedWeather(ctx: Context): String? = sp(ctx).getString("w_cache", null)

    // Auto-update interval
    fun getAutoUpdateIdx(ctx: Context): Int = sp(ctx).getInt("auto_upd_idx", 0).coerceIn(0, AUTO_UPDATE_MINUTES.lastIndex)
    fun setAutoUpdateIdx(ctx: Context, idx: Int) = sp(ctx).edit().putInt("auto_upd_idx", idx.coerceIn(0, AUTO_UPDATE_MINUTES.lastIndex)).apply()
    fun getAutoUpdateMinutes(ctx: Context): Int = AUTO_UPDATE_MINUTES[getAutoUpdateIdx(ctx)]

    // Hide/Show Clocks
    fun isHideClock1(ctx: Context): Boolean = sp(ctx).getBoolean("hide_c1", false)
    fun setHideClock1(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("hide_c1", v).apply()

    fun isHideClock2(ctx: Context): Boolean = sp(ctx).getBoolean("hide_c2", false)
    fun setHideClock2(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("hide_c2", v).apply()

    fun isHideClock3(ctx: Context): Boolean = sp(ctx).getBoolean("hide_c3", false)
    fun setHideClock3(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("hide_c3", v).apply()

    // Country Selection
    fun getClock1Idx(ctx: Context): Int = sp(ctx).getInt("c1", 0).coerceIn(0, COUNTRIES.lastIndex)
    fun setClock1Idx(ctx: Context, i: Int) = sp(ctx).edit().putInt("c1", i.coerceIn(0, COUNTRIES.lastIndex)).apply()

    fun getClock2Idx(ctx: Context): Int = sp(ctx).getInt("c2", 1).coerceIn(0, COUNTRIES.lastIndex)
    fun setClock2Idx(ctx: Context, i: Int) = sp(ctx).edit().putInt("c2", i.coerceIn(0, COUNTRIES.lastIndex)).apply()

    fun getClock3Idx(ctx: Context): Int = sp(ctx).getInt("c3", 2).coerceIn(0, COUNTRIES.lastIndex)
    fun setClock3Idx(ctx: Context, i: Int) = sp(ctx).edit().putInt("c3", i.coerceIn(0, COUNTRIES.lastIndex)).apply()

    // Font Sizes
    fun getClockSize(ctx: Context): Float = sp(ctx).getFloat("sz_clock", DEFAULT_CLOCK_SIZE)
    fun setClockSize(ctx: Context, v: Float) = sp(ctx).edit().putFloat("sz_clock", v.coerceIn(22f, 64f)).apply()

    fun getDateSize(ctx: Context): Float = sp(ctx).getFloat("sz_date", DEFAULT_DATE_SIZE)
    fun setDateSize(ctx: Context, v: Float) = sp(ctx).edit().putFloat("sz_date", v.coerceIn(12f, 34f)).apply()

    fun getMonthEndSize(ctx: Context): Float = sp(ctx).getFloat("sz_mend", DEFAULT_MONTH_END_SIZE)
    fun setMonthEndSize(ctx: Context, v: Float) = sp(ctx).edit().putFloat("sz_mend", v.coerceIn(8f, 26f)).apply()

    fun getDaySize(ctx: Context): Float = sp(ctx).getFloat("sz_day", DEFAULT_DAY_SIZE)
    fun setDaySize(ctx: Context, v: Float) = sp(ctx).edit().putFloat("sz_day", v.coerceIn(12f, 34f)).apply()

    // Designs & Fonts
    fun getClockDesignIdx(ctx: Context): Int = sp(ctx).getInt("clock_design", 0).coerceIn(0, 19)
    fun setClockDesignIdx(ctx: Context, i: Int) = sp(ctx).edit().putInt("clock_design", i.coerceIn(0, 19)).apply()

    fun getFontIdx(ctx: Context): Int = sp(ctx).getInt("font_idx", 0).coerceIn(0, 19)
    fun setFontIdx(ctx: Context, i: Int) = sp(ctx).edit().putInt("font_idx", i.coerceIn(0, 19)).apply()

    fun isAutoDayNightColor(ctx: Context): Boolean = sp(ctx).getBoolean("auto_dn_color", true)
    fun setAutoDayNightColor(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("auto_dn_color", v).apply()

    fun isBorderEnabled(ctx: Context): Boolean = sp(ctx).getBoolean("border_on", true)
    fun setBorderEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("border_on", v).apply()

    fun isHour12(ctx: Context): Boolean = sp(ctx).getBoolean("hour12", false)
    fun setHour12(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("hour12", v).apply()

    fun isTransparent(ctx: Context): Boolean = sp(ctx).getBoolean("transparent", false)
    fun setTransparent(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("transparent", v).apply()

    // Custom Colors
    fun getClockColor(ctx: Context): Int = sp(ctx).getInt("col_clock", 0xFFFFFFFF.toInt())
    fun setClockColor(ctx: Context, c: Int) = sp(ctx).edit().putInt("col_clock", c).apply()

    fun getDateColor(ctx: Context): Int = sp(ctx).getInt("col_date", 0xFFFACC15.toInt())
    fun setDateColor(ctx: Context, c: Int) = sp(ctx).edit().putInt("col_date", c).apply()

    fun getDayColor(ctx: Context): Int = sp(ctx).getInt("col_day", 0xFFEF4444.toInt())
    fun setDayColor(ctx: Context, c: Int) = sp(ctx).edit().putInt("col_day", c).apply()

    fun getBorderColor(ctx: Context): Int = sp(ctx).getInt("col_border", 0xFF000000.toInt())
    fun setBorderColor(ctx: Context, c: Int) = sp(ctx).edit().putInt("col_border", c).apply()

    fun resetAll(ctx: Context) {
        sp(ctx).edit().clear().apply()
    }
}
