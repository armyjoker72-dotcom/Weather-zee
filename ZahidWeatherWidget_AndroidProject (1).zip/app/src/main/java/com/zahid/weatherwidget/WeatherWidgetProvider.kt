package com.zahid.weatherwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.view.View
import android.widget.RemoteViews
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class WeatherWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH = "com.zahid.weatherwidget.ACTION_REFRESH"
        private val executor = Executors.newSingleThreadExecutor()

        private val URDU_DAYS = mapOf(
            Calendar.SUNDAY to "اتوار",
            Calendar.MONDAY to "سوموار",
            Calendar.TUESDAY to "منگل",
            Calendar.WEDNESDAY to "بدھ",
            Calendar.THURSDAY to "جمعرات",
            Calendar.FRIDAY to "جمعۃ المبارک",
            Calendar.SATURDAY to "ہفتہ"
        )

        fun updateAllWidgets(context: Context, fetchNetwork: Boolean = true) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, WeatherWidgetProvider::class.java))
            if (ids.isEmpty()) return

            // Immediately render cached/local data so UI feels instant
            val cached = Prefs.getCachedWeather(context)
            for (id in ids) {
                renderWidget(context, manager, id, cached)
            }

            if (fetchNetwork) {
                executor.execute {
                    val lat = Prefs.getLat(context)
                    val lon = Prefs.getLon(context)
                    val apiUrl = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                        "&current=temperature_2m,is_day,weather_code" +
                        "&daily=weather_code,temperature_2m_max,temperature_2m_min" +
                        "&timezone=auto&forecast_days=5"
                    try {
                        val conn = URL(apiUrl).openConnection() as HttpURLConnection
                        conn.connectTimeout = 10000
                        conn.readTimeout = 10000
                        conn.requestMethod = "GET"
                        if (conn.responseCode == 200) {
                            val response = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                            Prefs.saveCachedWeather(context, response)
                            for (id in ids) {
                                renderWidget(context, manager, id, response)
                            }
                        }
                        conn.disconnect()
                    } catch (_: Exception) {
                        // Keep cached data if offline
                    }
                }
            }
        }

        private fun renderWidget(
            context: Context,
            manager: AppWidgetManager,
            appWidgetId: Int,
            jsonStr: String?
        ) {
            val views = RemoteViews(context.packageName, R.layout.widget_weather)

            // Click widget -> open Settings activity
            val openIntent = Intent(context, MainActivity::class.java)
            val openPi = PendingIntent.getActivity(
                context, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, openPi)

            // Click Hero Icon -> Refresh weather immediately
            val refreshIntent = Intent(context, WeatherWidgetProvider::class.java).apply {
                action = ACTION_REFRESH
            }
            val refreshPi = PendingIntent.getBroadcast(
                context, 1, refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.hero_icon, refreshPi)

            // Date + Days in Month (thin smaller brackets)
            val cal = Calendar.getInstance()
            val dayNum = cal.get(Calendar.DAY_OF_MONTH)
            val monthName = SimpleDateFormat("MMMM", Locale.US).format(cal.time)
            val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            val dateBase = "$dayNum $monthName "
            val dateFullStr = "$dateBase($daysInMonth)"
            val dateSpannable = SpannableString(dateFullStr).apply {
                setSpan(RelativeSizeSpan(0.80f), dateBase.length, dateFullStr.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            views.setTextViewText(R.id.date_full, dateSpannable)

            // Weekday + Urdu Day in brackets (same size)
            val engDay = SimpleDateFormat("EEEE", Locale.US).format(cal.time)
            val urduDay = URDU_DAYS[cal.get(Calendar.DAY_OF_WEEK)] ?: ""
            views.setTextViewText(R.id.day_full, "$engDay ($urduDay)")

            // City Name
            views.setTextViewText(R.id.city_name, Prefs.getCity(context))

            // Active Clock Font (1 of 15) + 12H/24H format
            val selectedFont = Prefs.getFontIndex(context)
            val hour12 = Prefs.isHour12(context)
            val timeFormat = if (hour12) "hh:mm a" else "HH:mm"
            for (i in Prefs.CLOCK_VIEW_IDS.indices) {
                val cid = Prefs.CLOCK_VIEW_IDS[i]
                if (i == selectedFont) {
                    views.setViewVisibility(cid, View.VISIBLE)
                    views.setCharSequence(cid, "setFormat12Hour", timeFormat)
                    views.setCharSequence(cid, "setFormat24Hour", timeFormat)
                } else {
                    views.setViewVisibility(cid, View.GONE)
                }
            }

            // Default background
            var bgRes = R.drawable.widget_bg_blue

            // Parse Weather JSON if available
            if (!jsonStr.isNullOrBlank()) {
                try {
                    val root = JSONObject(jsonStr)
                    val useF = Prefs.isFahrenheit(context)

                    val current = root.getJSONObject("current")
                    val curTemp = formatTemp(current.getDouble("temperature_2m"), useF)
                    val isDay = current.optInt("is_day", 1) == 1
                    val curCode = current.optInt("weather_code", 0)
                    val wInfo = mapWeatherCode(curCode, isDay)

                    bgRes = wInfo.bgRes
                    views.setImageViewResource(R.id.hero_icon, wInfo.iconRes)
                    views.setTextViewText(R.id.current_temp, "${curTemp}°")
                    views.setTextViewText(R.id.current_cond, wInfo.label)

                    val daily = root.getJSONObject("daily")
                    val times = daily.getJSONArray("time")
                    val codes = daily.getJSONArray("weather_code")
                    val maxArr = daily.getJSONArray("temperature_2m_max")
                    val minArr = daily.getJSONArray("temperature_2m_min")

                    if (times.length() > 0) {
                        val loToday = formatTemp(minArr.getDouble(0), useF)
                        val hiToday = formatTemp(maxArr.getDouble(0), useF)
                        views.setTextViewText(R.id.today_range, "L:${loToday}° ~ H:${hiToday}°")
                    }

                    val nameIds = intArrayOf(R.id.d1_name, R.id.d2_name, R.id.d3_name)
                    val iconIds = intArrayOf(R.id.d1_icon, R.id.d2_icon, R.id.d3_icon)
                    val tempIds = intArrayOf(R.id.d1_temps, R.id.d2_temps, R.id.d3_temps)

                    val inFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                    val outFmt = SimpleDateFormat("EEE", Locale.US)

                    for (idx in 0..2) {
                        val dayIdx = idx + 1
                        if (dayIdx < times.length()) {
                            val dDate: Date? = inFmt.parse(times.getString(dayIdx))
                            val dayLabel = if (dDate != null) outFmt.format(dDate).uppercase(Locale.US) else "---"
                            val dW = mapWeatherCode(codes.getInt(dayIdx), true)
                            val dMin = formatTemp(minArr.getDouble(dayIdx), useF)
                            val dMax = formatTemp(maxArr.getDouble(dayIdx), useF)

                            views.setTextViewText(nameIds[idx], dayLabel)
                            views.setImageViewResource(iconIds[idx], dW.iconRes)
                            views.setTextViewText(tempIds[idx], "$dMin/$dMax°")
                        }
                    }
                } catch (_: Exception) {
                }
            }

            // Apply Transparent or Weather Background
            if (Prefs.isTransparent(context)) {
                views.setInt(R.id.widget_root, "setBackgroundResource", R.drawable.widget_bg_transparent)
            } else {
                views.setInt(R.id.widget_root, "setBackgroundResource", bgRes)
            }

            manager.updateAppWidget(appWidgetId, views)
        }

        private fun formatTemp(c: Double, fahrenheit: Boolean): Int {
            val v = if (fahrenheit) (c * 9.0 / 5.0) + 32.0 else c
            return v.roundToInt()
        }

        private data class WeatherVisual(val label: String, val iconRes: Int, val bgRes: Int)

        private fun mapWeatherCode(code: Int, isDay: Boolean): WeatherVisual {
            return when (code) {
                0 -> WeatherVisual(
                    "Clear",
                    if (isDay) R.drawable.ic_weather_clear_day else R.drawable.ic_weather_clear_night,
                    if (isDay) R.drawable.widget_bg_blue else R.drawable.widget_bg_night
                )
                1 -> WeatherVisual(
                    "Mainly Clear",
                    if (isDay) R.drawable.ic_weather_clear_day else R.drawable.ic_weather_clear_night,
                    if (isDay) R.drawable.widget_bg_blue else R.drawable.widget_bg_night
                )
                2 -> WeatherVisual(
                    "Partly Cloudy",
                    if (isDay) R.drawable.ic_weather_partly_cloudy_day else R.drawable.ic_weather_partly_cloudy_night,
                    if (isDay) R.drawable.widget_bg_blue else R.drawable.widget_bg_night
                )
                3 -> WeatherVisual(
                    "Cloudy",
                    R.drawable.ic_weather_cloudy,
                    if (isDay) R.drawable.widget_bg_blue else R.drawable.widget_bg_night
                )
                45, 48 -> WeatherVisual("Foggy", R.drawable.ic_weather_fog, R.drawable.widget_bg_blue)
                51, 53, 55, 56, 57 -> WeatherVisual("Drizzle", R.drawable.ic_weather_rain, R.drawable.widget_bg_rain)
                61, 63, 65, 66, 67, 80, 81, 82 -> WeatherVisual("Rain", R.drawable.ic_weather_rain, R.drawable.widget_bg_rain)
                71, 73, 75, 77, 85, 86 -> WeatherVisual("Snow", R.drawable.ic_weather_snow, R.drawable.widget_bg_rain)
                95, 96, 99 -> WeatherVisual("Storm", R.drawable.ic_weather_storm, R.drawable.widget_bg_rain)
                else -> WeatherVisual(
                    "Clear",
                    if (isDay) R.drawable.ic_weather_clear_day else R.drawable.ic_weather_clear_night,
                    R.drawable.widget_bg_blue
                )
            }
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        updateAllWidgets(context, fetchNetwork = true)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_REFRESH,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> updateAllWidgets(context, fetchNetwork = true)
        }
    }
}
