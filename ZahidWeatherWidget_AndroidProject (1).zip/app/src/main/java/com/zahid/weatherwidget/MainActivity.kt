package com.zahid.weatherwidget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.res.ResourcesCompat
import com.google.android.material.switchmaterial.SwitchMaterial
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnPin = findViewById<Button>(R.id.btnPinWidget)
        val btnRefresh = findViewById<Button>(R.id.btnRefreshNow)
        val tvCurrentCity = findViewById<TextView>(R.id.tvCurrentCity)
        val etCitySearch = findViewById<EditText>(R.id.etCitySearch)
        val btnSearchCity = findViewById<Button>(R.id.btnSearchCity)
        val tvCityStatus = findViewById<TextView>(R.id.tvCityStatus)
        val swTransparent = findViewById<SwitchMaterial>(R.id.swTransparent)
        val swHour12 = findViewById<SwitchMaterial>(R.id.swHour12)
        val swFahrenheit = findViewById<SwitchMaterial>(R.id.swFahrenheit)
        val spClockFont = findViewById<Spinner>(R.id.spClockFont)
        val tvFontPreview = findViewById<TextView>(R.id.tvFontPreview)

        fun updateCityLabel() {
            val c = Prefs.getCity(this)
            val country = Prefs.getCountry(this)
            tvCurrentCity.text = if (country.isNotBlank()) "$c, $country" else c
        }

        updateCityLabel()

        // Pin Widget directly to Home Screen
        btnPin.setOnClickListener {
            val mgr = AppWidgetManager.getInstance(this)
            val provider = ComponentName(this, WeatherWidgetProvider::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(provider, null, null)
            } else {
                Toast.makeText(
                    this,
                    "Long-press your Home Screen -> Widgets -> Zahid Weather & Clock",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        btnRefresh.setOnClickListener {
            WeatherWidgetProvider.updateAllWidgets(this, fetchNetwork = true)
            Toast.makeText(this, "Refreshing live weather...", Toast.LENGTH_SHORT).show()
        }

        // City Search using Open-Meteo Geocoding API
        btnSearchCity.setOnClickListener {
            val query = etCitySearch.text.toString().trim()
            if (query.length < 2) {
                tvCityStatus.text = "Please type a valid city name."
                return@setOnClickListener
            }
            tvCityStatus.text = "Searching $query..."
            executor.execute {
                try {
                    val encoded = URLEncoder.encode(query, "UTF-8")
                    val url = "https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=en&format=json"
                    val conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = 8000
                    conn.readTimeout = 8000
                    val text = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                    conn.disconnect()

                    val json = JSONObject(text)
                    val results = json.optJSONArray("results")
                    if (results != null && results.length() > 0) {
                        val first = results.getJSONObject(0)
                        val name = first.getString("name")
                        val country = first.optString("country", "")
                        val lat = first.getDouble("latitude")
                        val lon = first.getDouble("longitude")
                        Prefs.setCity(this, name, country, lat, lon)
                        runOnUiThread {
                            updateCityLabel()
                            etCitySearch.setText("")
                            tvCityStatus.text = "City set to $name!"
                            WeatherWidgetProvider.updateAllWidgets(this, fetchNetwork = true)
                        }
                    } else {
                        runOnUiThread { tvCityStatus.text = "City not found. Try another spelling." }
                    }
                } catch (_: Exception) {
                    runOnUiThread { tvCityStatus.text = "Network error. Check internet connection." }
                }
            }
        }

        // Switches
        swTransparent.isChecked = Prefs.isTransparent(this)
        swTransparent.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setTransparent(this, isChecked)
            WeatherWidgetProvider.updateAllWidgets(this, fetchNetwork = false)
        }

        swHour12.isChecked = Prefs.isHour12(this)
        swHour12.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setHour12(this, isChecked)
            WeatherWidgetProvider.updateAllWidgets(this, fetchNetwork = false)
        }

        swFahrenheit.isChecked = Prefs.isFahrenheit(this)
        swFahrenheit.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setFahrenheit(this, isChecked)
            WeatherWidgetProvider.updateAllWidgets(this, fetchNetwork = false)
        }

        // 15 Clock Fonts Spinner
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Prefs.FONT_LABELS)
        spClockFont.adapter = adapter
        val savedFont = Prefs.getFontIndex(this)
        spClockFont.setSelection(savedFont)
        tvFontPreview.typeface = ResourcesCompat.getFont(this, Prefs.FONT_RES_IDS[savedFont])

        spClockFont.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                Prefs.setFontIndex(this@MainActivity, position)
                tvFontPreview.typeface = ResourcesCompat.getFont(this@MainActivity, Prefs.FONT_RES_IDS[position])
                WeatherWidgetProvider.updateAllWidgets(this@MainActivity, fetchNetwork = false)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }
}
