package com.zahid.weatherwidget

import android.content.Context

object Prefs {
    private const val PREF_NAME = "zahid_weather_prefs"

    const val DEFAULT_CITY = "Rahim Yar Khan"
    const val DEFAULT_COUNTRY = "Pakistan"
    const val DEFAULT_LAT = 28.4212
    const val DEFAULT_LON = 70.2989

    val FONT_LABELS = listOf(
        "1. Lato Black (Modern Bold)",
        "2. Lato Heavy Italic",
        "3. DejaVu Sans Bold",
        "4. DejaVu Sans Condensed",
        "5. DejaVu Serif Bold",
        "6. DejaVu Serif Condensed",
        "7. DejaVu Mono (Digital)",
        "8. Liberation Mono Bold",
        "9. Liberation Narrow Bold",
        "10. Liberation Serif Bold",
        "11. URW Gothic (Geometric)",
        "12. URW Bookman (Classic)",
        "13. Palatino Bold (Luxury)",
        "14. Century Bold",
        "15. Chancery Stylish Italic"
    )

    val FONT_RES_IDS = intArrayOf(
        R.font.font_01, R.font.font_02, R.font.font_03, R.font.font_04, R.font.font_05,
        R.font.font_06, R.font.font_07, R.font.font_08, R.font.font_09, R.font.font_10,
        R.font.font_11, R.font.font_12, R.font.font_13, R.font.font_14, R.font.font_15
    )

    val CLOCK_VIEW_IDS = intArrayOf(
        R.id.clock_font_0, R.id.clock_font_1, R.id.clock_font_2, R.id.clock_font_3, R.id.clock_font_4,
        R.id.clock_font_5, R.id.clock_font_6, R.id.clock_font_7, R.id.clock_font_8, R.id.clock_font_9,
        R.id.clock_font_10, R.id.clock_font_11, R.id.clock_font_12, R.id.clock_font_13, R.id.clock_font_14
    )

    private fun sp(ctx: Context) = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    fun getCity(ctx: Context): String = sp(ctx).getString("city", DEFAULT_CITY) ?: DEFAULT_CITY
    fun getCountry(ctx: Context): String = sp(ctx).getString("country", DEFAULT_COUNTRY) ?: DEFAULT_COUNTRY
    fun getLat(ctx: Context): Double = java.lang.Double.longBitsToDouble(
        sp(ctx).getLong("lat", java.lang.Double.doubleToRawLongBits(DEFAULT_LAT))
    )
    fun getLon(ctx: Context): Double = java.lang.Double.longBitsToDouble(
        sp(ctx).getLong("lon", java.lang.Double.doubleToRawLongBits(DEFAULT_LON))
    )

    fun setCity(ctx: Context, name: String, country: String, lat: Double, lon: Double) {
        sp(ctx).edit()
            .putString("city", name)
            .putString("country", country)
            .putLong("lat", java.lang.Double.doubleToRawLongBits(lat))
            .putLong("lon", java.lang.Double.doubleToRawLongBits(lon))
            .apply()
    }

    fun isTransparent(ctx: Context): Boolean = sp(ctx).getBoolean("transparent", false)
    fun setTransparent(ctx: Context, value: Boolean) = sp(ctx).edit().putBoolean("transparent", value).apply()

    fun isHour12(ctx: Context): Boolean = sp(ctx).getBoolean("hour12", false)
    fun setHour12(ctx: Context, value: Boolean) = sp(ctx).edit().putBoolean("hour12", value).apply()

    fun isFahrenheit(ctx: Context): Boolean = sp(ctx).getBoolean("fahrenheit", false)
    fun setFahrenheit(ctx: Context, value: Boolean) = sp(ctx).edit().putBoolean("fahrenheit", value).apply()

    fun getFontIndex(ctx: Context): Int = sp(ctx).getInt("font_index", 0).coerceIn(0, 14)
    fun setFontIndex(ctx: Context, index: Int) = sp(ctx).edit().putInt("font_index", index.coerceIn(0, 14)).apply()

    fun saveCachedWeather(ctx: Context, json: String) = sp(ctx).edit().putString("cached_json", json).apply()
    fun getCachedWeather(ctx: Context): String? = sp(ctx).getString("cached_json", null)
}
