package com.zahid.weatherwidget

import android.content.Context

object Prefs {
    private const val PREF_NAME = "zahid_weather_prefs"

    const val DEFAULT_CITY = "Rahim Yar Khan"
    const val DEFAULT_COUNTRY = "Pakistan"
    const val DEFAULT_LAT = 28.4212
    const val DEFAULT_LON = 70.2989

    // Default Font Sizes (sp)
    const val DEFAULT_DATE_SIZE = 17f
    const val DEFAULT_DAY_SIZE = 15f
    const val DEFAULT_CLOCK_SIZE = 46f
    const val DEFAULT_CITY_SIZE = 16f
    const val DEFAULT_WEATHER_SIZE = 42f
    const val DEFAULT_FORECAST_SIZE = 14f

    // Default Fill Colors (ARGB)
    const val DEFAULT_DATE_COLOR = 0xFFFFFFFF.toInt()
    const val DEFAULT_DAY_COLOR = 0xFFE0F2FE.toInt()
    const val DEFAULT_CLOCK_COLOR = 0xFFFFFFFF.toInt()
    const val DEFAULT_CITY_COLOR = 0xFFF8FAFC.toInt()
    const val DEFAULT_WEATHER_COLOR = 0xFFFFFFFF.toInt()
    const val DEFAULT_FORECAST_COLOR = 0xFFFFFFFF.toInt()

    // Default Border Colors (ARGB)
    const val DEFAULT_BORDER_COLOR = 0xFF000000.toInt()
    const val DEFAULT_BORDER_WIDTH = 3f

    val FONT_LABELS = listOf(
        "1. Lato Black (Modern Bold)",
        "2. Lato Heavy Italic",
        "3. DejaVu Sans Bold",
        "4. DejaVu Sans Condensed",
        "5. DejaVu Serif Bold",
        "6. DejaVu Serif Condensed",
        "7. DejaVu Mono (Digital)",
        "8. Liberation Mono Bold",
        "9. Liberation Narrow Bold",
        "10. Liberation Serif Bold",
        "11. URW Gothic (Geometric)",
        "12. URW Bookman (Classic)",
        "13. Palatino Bold (Luxury)",
        "14. Century Bold",
        "15. Chancery Stylish Italic",
        "16. [3D] Block Bold 3D",
        "17. [3D] Slanted Heavy 3D",
        "18. [3D] Digital Cyber 3D",
        "19. [3D] Geometric Pop 3D",
        "20. [3D] Luxury Serif 3D"
    )

    val FONT_RES_IDS = intArrayOf(
        R.font.font_01, R.font.font_02, R.font.font_03, R.font.font_04, R.font.font_05,
        R.font.font_06, R.font.font_07, R.font.font_08, R.font.font_09, R.font.font_10,
        R.font.font_11, R.font.font_12, R.font.font_13, R.font.font_14, R.font.font_15,
        R.font.font_01, R.font.font_02, R.font.font_07, R.font.font_11, R.font.font_13
    )

    val CLOCK_LAYOUT_RES_IDS = intArrayOf(
        R.layout.clock_style_00, R.layout.clock_style_01, R.layout.clock_style_02, R.layout.clock_style_03, R.layout.clock_style_04,
        R.layout.clock_style_05, R.layout.clock_style_06, R.layout.clock_style_07, R.layout.clock_style_08, R.layout.clock_style_09,
        R.layout.clock_style_10, R.layout.clock_style_11, R.layout.clock_style_12, R.layout.clock_style_13, R.layout.clock_style_14,
        R.layout.clock_style_15, R.layout.clock_style_16, R.layout.clock_style_17, R.layout.clock_style_18, R.layout.clock_style_19
    )

    fun is3DFont(index: Int): Boolean = index >= 15

    private fun sp(ctx: Context) = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    fun getCity(ctx: Context): String = sp(ctx).getString("city", DEFAULT_CITY) ?: DEFAULT_CITY
    fun getCountry(ctx: Context): String = sp(ctx).getString("country", DEFAULT_COUNTRY) ?: DEFAULT_COUNTRY
    fun getLat(ctx: Context): Double = java.lang.Double.longBitsToDouble(
        sp(ctx).getLong("lat", java.lang.Double.doubleToRawLongBits(DEFAULT_LAT))
    )
    fun getLon(ctx: Context): Double = java.lang.Double.longBitsToDouble(
        sp(ctx).getLong("lon", java.lang.Double.doubleToRawLongBits(DEFAULT_LON))
    )

    fun setCity(ctx: Context, name: String, country: String, lat: Double, lon: Double) {
        sp(ctx).edit()
            .putString("city", name)
            .putString("country", country)
            .putLong("lat", java.lang.Double.doubleToRawLongBits(lat))
            .putLong("lon", java.lang.Double.doubleToRawLongBits(lon))
            .apply()
    }

    fun isTransparent(ctx: Context): Boolean = sp(ctx).getBoolean("transparent", false)
    fun setTransparent(ctx: Context, value: Boolean) = sp(ctx).edit().putBoolean("transparent", value).apply()

    fun isHour12(ctx: Context): Boolean = sp(ctx).getBoolean("hour12", false)
    fun setHour12(ctx: Context, value: Boolean) = sp(ctx).edit().putBoolean("hour12", value).apply()

    fun isFahrenheit(ctx: Context): Boolean = sp(ctx).getBoolean("fahrenheit", false)
    fun setFahrenheit(ctx: Context, value: Boolean) = sp(ctx).edit().putBoolean("fahrenheit", value).apply()

    fun getFontIndex(ctx: Context): Int = sp(ctx).getInt("font_index", 0).coerceIn(0, 19)
    fun setFontIndex(ctx: Context, index: Int) = sp(ctx).edit().putInt("font_index", index.coerceIn(0, 19)).apply()

    // Font Sizes
    fun getDateSize(ctx: Context): Float = sp(ctx).getFloat("size_date", DEFAULT_DATE_SIZE)
    fun setDateSize(ctx: Context, v: Float) = sp(ctx).edit().putFloat("size_date", v.coerceIn(10f, 26f)).apply()

    fun getDaySize(ctx: Context): Float = sp(ctx).getFloat("size_day", DEFAULT_DAY_SIZE)
    fun setDaySize(ctx: Context, v: Float) = sp(ctx).edit().putFloat("size_day", v.coerceIn(10f, 24f)).apply()

    fun getClockSize(ctx: Context): Float = sp(ctx).getFloat("size_clock", DEFAULT_CLOCK_SIZE)
    fun setClockSize(ctx: Context, v: Float) = sp(ctx).edit().putFloat("size_clock", v.coerceIn(26f, 66f)).apply()

    fun getCitySize(ctx: Context): Float = sp(ctx).getFloat("size_city", DEFAULT_CITY_SIZE)
    fun setCitySize(ctx: Context, v: Float) = sp(ctx).edit().putFloat("size_city", v.coerceIn(10f, 26f)).apply()

    fun getWeatherSize(ctx: Context): Float = sp(ctx).getFloat("size_weather", DEFAULT_WEATHER_SIZE)
    fun setWeatherSize(ctx: Context, v: Float) = sp(ctx).edit().putFloat("size_weather", v.coerceIn(24f, 58f)).apply()

    fun getForecastSize(ctx: Context): Float = sp(ctx).getFloat("size_forecast", DEFAULT_FORECAST_SIZE)
    fun setForecastSize(ctx: Context, v: Float) = sp(ctx).edit().putFloat("size_forecast", v.coerceIn(9f, 22f)).apply()

    // Fill Colors
    fun getDateColor(ctx: Context): Int = sp(ctx).getInt("color_date", DEFAULT_DATE_COLOR)
    fun setDateColor(ctx: Context, c: Int) = sp(ctx).edit().putInt("color_date", c).apply()

    fun getDayColor(ctx: Context): Int = sp(ctx).getInt("color_day", DEFAULT_DAY_COLOR)
    fun setDayColor(ctx: Context, c: Int) = sp(ctx).edit().putInt("color_day", c).apply()

    fun getClockColor(ctx: Context): Int = sp(ctx).getInt("color_clock", DEFAULT_CLOCK_COLOR)
    fun setClockColor(ctx: Context, c: Int) = sp(ctx).edit().putInt("color_clock", c).apply()

    fun getCityColor(ctx: Context): Int = sp(ctx).getInt("color_city", DEFAULT_CITY_COLOR)
    fun setCityColor(ctx: Context, c: Int) = sp(ctx).edit().putInt("color_city", c).apply()

    fun getWeatherColor(ctx: Context): Int = sp(ctx).getInt("color_weather", DEFAULT_WEATHER_COLOR)
    fun setWeatherColor(ctx: Context, c: Int) = sp(ctx).edit().putInt("color_weather", c).apply()

    fun getForecastColor(ctx: Context): Int = sp(ctx).getInt("color_forecast", DEFAULT_FORECAST_COLOR)
    fun setForecastColor(ctx: Context, c: Int) = sp(ctx).edit().putInt("color_forecast", c).apply()

    // Text Border & 3D Controls
    fun isBorderEnabled(ctx: Context): Boolean = sp(ctx).getBoolean("border_enabled", true)
    fun setBorderEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("border_enabled", v).apply()

    fun getBorderWidth(ctx: Context): Float = sp(ctx).getFloat("border_width", DEFAULT_BORDER_WIDTH)
    fun setBorderWidth(ctx: Context, v: Float) = sp(ctx).edit().putFloat("border_width", v.coerceIn(1f, 6f)).apply()

    fun isTop3DEnabled(ctx: Context): Boolean = sp(ctx).getBoolean("top_3d_enabled", false)
    fun setTop3DEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("top_3d_enabled", v).apply()

    fun getDateBorderColor(ctx: Context): Int = sp(ctx).getInt("bcolor_date", DEFAULT_BORDER_COLOR)
    fun setDateBorderColor(ctx: Context, c: Int) = sp(ctx).edit().putInt("bcolor_date", c).apply()

    fun getDayBorderColor(ctx: Context): Int = sp(ctx).getInt("bcolor_day", DEFAULT_BORDER_COLOR)
    fun setDayBorderColor(ctx: Context, c: Int) = sp(ctx).edit().putInt("bcolor_day", c).apply()

    fun getClockBorderColor(ctx: Context): Int = sp(ctx).getInt("bcolor_clock", DEFAULT_BORDER_COLOR)
    fun setClockBorderColor(ctx: Context, c: Int) = sp(ctx).edit().putInt("bcolor_clock", c).apply()

    fun getCityBorderColor(ctx: Context): Int = sp(ctx).getInt("bcolor_city", DEFAULT_BORDER_COLOR)
    fun setCityBorderColor(ctx: Context, c: Int) = sp(ctx).edit().putInt("bcolor_city", c).apply()

    fun resetAppearance(ctx: Context) {
        sp(ctx).edit()
            .putFloat("size_date", DEFAULT_DATE_SIZE)
            .putFloat("size_day", DEFAULT_DAY_SIZE)
            .putFloat("size_clock", DEFAULT_CLOCK_SIZE)
            .putFloat("size_city", DEFAULT_CITY_SIZE)
            .putFloat("size_weather", DEFAULT_WEATHER_SIZE)
            .putFloat("size_forecast", DEFAULT_FORECAST_SIZE)
            .putInt("color_date", DEFAULT_DATE_COLOR)
            .putInt("color_day", DEFAULT_DAY_COLOR)
            .putInt("color_clock", DEFAULT_CLOCK_COLOR)
            .putInt("color_city", DEFAULT_CITY_COLOR)
            .putInt("color_weather", DEFAULT_WEATHER_COLOR)
            .putInt("color_forecast", DEFAULT_FORECAST_COLOR)
            .putBoolean("border_enabled", true)
            .putFloat("border_width", DEFAULT_BORDER_WIDTH)
            .putBoolean("top_3d_enabled", false)
            .putInt("bcolor_date", DEFAULT_BORDER_COLOR)
            .putInt("bcolor_day", DEFAULT_BORDER_COLOR)
            .putInt("bcolor_clock", DEFAULT_BORDER_COLOR)
            .putInt("bcolor_city", DEFAULT_BORDER_COLOR)
            .apply()
    }

    fun saveCachedWeather(ctx: Context, json: String) = sp(ctx).edit().putString("cached_json", json).apply()
    fun getCachedWeather(ctx: Context): String? = sp(ctx).getString("cached_json", null)
}
