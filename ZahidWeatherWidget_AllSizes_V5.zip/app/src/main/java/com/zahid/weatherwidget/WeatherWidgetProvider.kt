package com.zahid.weatherwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.ceil
import kotlin.math.roundToInt

enum class WidgetSizeType(val layoutRes: Int) {
    SIZE_1X1(R.layout.widget_weather_1x1),
    SIZE_2X2(R.layout.widget_weather_2x2),
    SIZE_4X2(R.layout.widget_weather),
    SIZE_4X4(R.layout.widget_weather_4x4)
}

open class WeatherWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH = "com.zahid.weatherwidget.ACTION_REFRESH"
        private val executor = Executors.newSingleThreadExecutor()

        private val URDU_DAYS = mapOf(
            Calendar.SUNDAY to "اتوار",
            Calendar.MONDAY to "سوموار",
            Calendar.TUESDAY to "منگل",
            Calendar.WEDNESDAY to "بدھ",
            Calendar.THURSDAY to "جمعرات",
            Calendar.FRIDAY to "جمعۃ المبارک",
            Calendar.SATURDAY to "ہفتہ"
        )

        private val ALL_PROVIDERS = listOf(
            Pair(WeatherWidgetProvider1x1::class.java, WidgetSizeType.SIZE_1X1),
            Pair(WeatherWidgetProvider2x2::class.java, WidgetSizeType.SIZE_2X2),
            Pair(WeatherWidgetProvider::class.java, WidgetSizeType.SIZE_4X2),
            Pair(WeatherWidgetProvider4x4::class.java, WidgetSizeType.SIZE_4X4)
        )

        fun updateAllWidgets(context: Context, fetchNetwork: Boolean = true) {
            val manager = AppWidgetManager.getInstance(context)
            var hasAny = false
            val cached = Prefs.getCachedWeather(context)

            for ((cls, sizeType) in ALL_PROVIDERS) {
                val ids = manager.getAppWidgetIds(ComponentName(context, cls))
                if (ids.isNotEmpty()) {
                    hasAny = true
                    for (id in ids) {
                        renderWidget(context, manager, id, sizeType, cached)
                    }
                }
            }
            if (!hasAny) return

            if (fetchNetwork) {
                executor.execute {
                    val lat = Prefs.getLat(context)
                    val lon = Prefs.getLon(context)
                    val apiUrl = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                        "&current=temperature_2m,is_day,weather_code" +
                        "&daily=weather_code,temperature_2m_max,temperature_2m_min" +
                        "&timezone=auto&forecast_days=5"
                    try {
                        val conn = URL(apiUrl).openConnection() as HttpURLConnection
                        conn.connectTimeout = 10000
                        conn.readTimeout = 10000
                        conn.requestMethod = "GET"
                        if (conn.responseCode == 200) {
                            val response = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                            Prefs.saveCachedWeather(context, response)
                            for ((cls, sizeType) in ALL_PROVIDERS) {
                                val ids = manager.getAppWidgetIds(ComponentName(context, cls))
                                for (id in ids) {
                                    renderWidget(context, manager, id, sizeType, response)
                                }
                            }
                        }
                        conn.disconnect()
                    } catch (_: Exception) {
                    }
                }
            }
        }

        private fun darkenColor(color: Int, factor: Float): Int {
            val r = (Color.red(color) * factor).roundToInt().coerceIn(0, 255)
            val g = (Color.green(color) * factor).roundToInt().coerceIn(0, 255)
            val b = (Color.blue(color) * factor).roundToInt().coerceIn(0, 255)
            return Color.argb(Color.alpha(color), r, g, b)
        }

        private fun renderStyledTextBitmap(
            context: Context,
            text: String,
            textSizeSp: Float,
            fillColor: Int,
            borderColor: Int,
            borderEnabled: Boolean,
            borderWidthDp: Float,
            enable3D: Boolean
        ): Bitmap {
            val dm = context.resources.displayMetrics
            val textPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, textSizeSp, dm)
            val strokePx = if (borderEnabled) {
                TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, borderWidthDp, dm)
            } else 0f
            val depthPx = if (enable3D) {
                TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 3.0f, dm)
            } else 0f

            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = textPx
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                isSubpixelText = true
            }

            val fm = paint.fontMetrics
            val textWidth = paint.measureText(text)
            val textHeight = fm.descent - fm.ascent

            val pad = ceil(strokePx + TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 2f, dm)).toInt()
            val extra3D = ceil(depthPx).toInt()

            val bmpW = (ceil(textWidth).toInt() + pad * 2 + extra3D).coerceAtLeast(16)
            val bmpH = (ceil(textHeight).toInt() + pad * 2 + extra3D).coerceAtLeast(16)

            val bitmap = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            val x = pad.toFloat()
            val y = pad.toFloat() - fm.ascent

            if (enable3D && extra3D > 0) {
                val base3DColor = if (borderEnabled) borderColor else darkenColor(fillColor, 0.35f)
                val steps = 5
                for (step in steps downTo 1) {
                    val ratio = step.toFloat() / steps.toFloat()
                    val offset = depthPx * ratio
                    val shadeFactor = 0.85f - (0.50f * ratio)
                    paint.style = Paint.Style.FILL
                    paint.color = darkenColor(base3DColor, shadeFactor)
                    canvas.drawText(text, x + offset, y + offset, paint)
                }
            }

            if (borderEnabled && strokePx > 0f) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = strokePx
                paint.strokeJoin = Paint.Join.ROUND
                paint.strokeCap = Paint.Cap.ROUND
                paint.color = borderColor
                canvas.drawText(text, x, y, paint)
            }

            paint.style = Paint.Style.FILL
            paint.color = fillColor
            canvas.drawText(text, x, y, paint)

            return bitmap
        }

        private fun renderWidget(
            context: Context,
            manager: AppWidgetManager,
            appWidgetId: Int,
            sizeType: WidgetSizeType,
            jsonStr: String?
        ) {
            val views = RemoteViews(context.packageName, sizeType.layoutRes)

            // Click widget -> open Settings
            val openIntent = Intent(context, MainActivity::class.java)
            val openPi = PendingIntent.getActivity(
                context, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, openPi)

            // Click Hero Icon -> Refresh weather
            val refreshIntent = Intent(context, WeatherWidgetProvider::class.java).apply {
                action = ACTION_REFRESH
            }
            val refreshPi = PendingIntent.getBroadcast(
                context, 1, refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.hero_icon, refreshPi)

            val borderOn = Prefs.isBorderEnabled(context)
            val borderW = Prefs.getBorderWidth(context)
            val selectedFont = Prefs.getFontIndex(context)
            val is3DClock = Prefs.is3DFont(selectedFont)
            val top3D = Prefs.isTop3DEnabled(context) || is3DClock

            val cal = Calendar.getInstance()
            val dayNum = cal.get(Calendar.DAY_OF_MONTH)
            val monthName = SimpleDateFormat("MMMM", Locale.US).format(cal.time)
            val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            val engDay = SimpleDateFormat("EEEE", Locale.US).format(cal.time)
            val urduDay = URDU_DAYS[cal.get(Calendar.DAY_OF_WEEK)] ?: ""

            // City image (present on all 4 sizes)
            val cityScale = when (sizeType) {
                WidgetSizeType.SIZE_1X1 -> 0.65f
                WidgetSizeType.SIZE_2X2 -> 0.80f
                WidgetSizeType.SIZE_4X2 -> 1.0f
                WidgetSizeType.SIZE_4X4 -> 1.12f
            }
            val cityBmp = renderStyledTextBitmap(
                context, Prefs.getCity(context),
                (Prefs.getCitySize(context) * cityScale).coerceIn(9f, 30f),
                Prefs.getCityColor(context), Prefs.getCityBorderColor(context),
                borderOn, if (sizeType == WidgetSizeType.SIZE_1X1) 1.5f else borderW,
                top3D && sizeType != WidgetSizeType.SIZE_1X1
            )
            views.setImageViewBitmap(R.id.city_img, cityBmp)

            // Date image (present on 2x2, 4x2, 4x4)
            if (sizeType != WidgetSizeType.SIZE_1X1) {
                val dateText = if (sizeType == WidgetSizeType.SIZE_2X2) {
                    "$dayNum $monthName"
                } else {
                    "$dayNum $monthName ($daysInMonth)"
                }
                val dateScale = when (sizeType) {
                    WidgetSizeType.SIZE_2X2 -> 0.78f
                    WidgetSizeType.SIZE_4X4 -> 1.10f
                    else -> 1.0f
                }
                val dateBmp = renderStyledTextBitmap(
                    context, dateText,
                    (Prefs.getDateSize(context) * dateScale).coerceIn(10f, 30f),
                    Prefs.getDateColor(context), Prefs.getDateBorderColor(context),
                    borderOn, borderW, top3D
                )
                views.setImageViewBitmap(R.id.date_img, dateBmp)
            }

            // Day image (present on 4x2, 4x4)
            if (sizeType == WidgetSizeType.SIZE_4X2 || sizeType == WidgetSizeType.SIZE_4X4) {
                val dayScale = if (sizeType == WidgetSizeType.SIZE_4X4) 1.10f else 1.0f
                val dayBmp = renderStyledTextBitmap(
                    context, "$engDay ($urduDay)",
                    (Prefs.getDaySize(context) * dayScale).coerceIn(10f, 28f),
                    Prefs.getDayColor(context), Prefs.getDayBorderColor(context),
                    borderOn, borderW, top3D
                )
                views.setImageViewBitmap(R.id.day_img, dayBmp)
            }

            // Live Clock (present on 2x2, 4x2, 4x4)
            if (sizeType != WidgetSizeType.SIZE_1X1) {
                val hour12 = Prefs.isHour12(context)
                val timeFormat = if (hour12) "hh:mm a" else "HH:mm"
                val clockScale = when (sizeType) {
                    WidgetSizeType.SIZE_2X2 -> 0.68f
                    WidgetSizeType.SIZE_4X4 -> 1.12f
                    else -> 1.0f
                }
                val clockSize = (Prefs.getClockSize(context) * clockScale).coerceIn(22f, 74f)
                val clockColor = Prefs.getClockColor(context)
                val clockBorderColor = Prefs.getClockBorderColor(context)

                views.removeAllViews(R.id.clock_container)
                val clockViews = RemoteViews(context.packageName, Prefs.CLOCK_LAYOUT_RES_IDS[selectedFont])

                fun styleClockLayer(viewId: Int, color: Int, visible: Boolean) {
                    clockViews.setViewVisibility(viewId, if (visible) View.VISIBLE else View.GONE)
                    if (visible) {
                        clockViews.setCharSequence(viewId, "setFormat12Hour", timeFormat)
                        clockViews.setCharSequence(viewId, "setFormat24Hour", timeFormat)
                        clockViews.setTextViewTextSize(viewId, TypedValue.COMPLEX_UNIT_SP, clockSize)
                        clockViews.setTextColor(viewId, color)
                    }
                }

                styleClockLayer(R.id.clock_main, clockColor, true)
                styleClockLayer(R.id.clock_b1, clockBorderColor, borderOn)
                styleClockLayer(R.id.clock_b2, clockBorderColor, borderOn)
                styleClockLayer(R.id.clock_b3, clockBorderColor, borderOn)
                styleClockLayer(R.id.clock_b4, clockBorderColor, borderOn)

                if (is3DClock) {
                    val base3D = if (borderOn) clockBorderColor else darkenColor(clockColor, 0.40f)
                    styleClockLayer(R.id.clock_3d_1, darkenColor(base3D, 0.85f), true)
                    styleClockLayer(R.id.clock_3d_2, darkenColor(base3D, 0.68f), true)
                    styleClockLayer(R.id.clock_3d_3, darkenColor(base3D, 0.52f), true)
                    styleClockLayer(R.id.clock_3d_4, darkenColor(base3D, 0.36f), true)
                }

                views.addView(R.id.clock_container, clockViews)
            }

            // Live Weather Section Styling
            val weatherSize = Prefs.getWeatherSize(context)
            val weatherColor = Prefs.getWeatherColor(context)
            val tempScale = when (sizeType) {
                WidgetSizeType.SIZE_1X1 -> 0.50f
                WidgetSizeType.SIZE_2X2 -> 0.72f
                WidgetSizeType.SIZE_4X2 -> 1.0f
                WidgetSizeType.SIZE_4X4 -> 1.14f
            }
            views.setTextViewTextSize(R.id.current_temp, TypedValue.COMPLEX_UNIT_SP, (weatherSize * tempScale).coerceIn(16f, 64f))
            views.setTextColor(R.id.current_temp, weatherColor)

            if (sizeType != WidgetSizeType.SIZE_1X1) {
                views.setTextViewTextSize(R.id.current_cond, TypedValue.COMPLEX_UNIT_SP, (weatherSize * 0.34f * tempScale).coerceIn(10f, 22f))
                views.setTextColor(R.id.current_cond, weatherColor)
            }

            if (sizeType == WidgetSizeType.SIZE_4X2 || sizeType == WidgetSizeType.SIZE_4X4) {
                views.setTextViewTextSize(R.id.today_range, TypedValue.COMPLEX_UNIT_SP, (weatherSize * 0.33f * tempScale).coerceIn(9f, 20f))
                views.setTextColor(R.id.today_range, weatherColor)

                val forecastScale = if (sizeType == WidgetSizeType.SIZE_4X4) 1.12f else 1.0f
                val forecastSize = (Prefs.getForecastSize(context) * forecastScale).coerceIn(9f, 24f)
                val forecastColor = Prefs.getForecastColor(context)
                val forecastTextIds = intArrayOf(
                    R.id.d1_name, R.id.d2_name, R.id.d3_name,
                    R.id.d1_temps, R.id.d2_temps, R.id.d3_temps
                )
                for (fid in forecastTextIds) {
                    views.setTextViewTextSize(fid, TypedValue.COMPLEX_UNIT_SP, forecastSize)
                    views.setTextColor(fid, forecastColor)
                }
            }

            var bgRes = R.drawable.widget_bg_blue

            if (!jsonStr.isNullOrBlank()) {
                try {
                    val root = JSONObject(jsonStr)
                    val useF = Prefs.isFahrenheit(context)

                    val current = root.getJSONObject("current")
                    val curTemp = formatTemp(current.getDouble("temperature_2m"), useF)
                    val isDay = current.optInt("is_day", 1) == 1
                    val curCode = current.optInt("weather_code", 0)
                    val wInfo = mapWeatherCode(curCode, isDay)

                    bgRes = wInfo.bgRes
                    views.setImageViewResource(R.id.hero_icon, wInfo.iconRes)
                    views.setTextViewText(R.id.current_temp, "${curTemp}°")

                    if (sizeType != WidgetSizeType.SIZE_1X1) {
                        views.setTextViewText(R.id.current_cond, wInfo.label)
                    }

                    if (sizeType == WidgetSizeType.SIZE_4X2 || sizeType == WidgetSizeType.SIZE_4X4) {
                        val daily = root.getJSONObject("daily")
                        val times = daily.getJSONArray("time")
                        val codes = daily.getJSONArray("weather_code")
                        val maxArr = daily.getJSONArray("temperature_2m_max")
                        val minArr = daily.getJSONArray("temperature_2m_min")

                        if (times.length() > 0) {
                            val loToday = formatTemp(minArr.getDouble(0), useF)
                            val hiToday = formatTemp(maxArr.getDouble(0), useF)
                            views.setTextViewText(R.id.today_range, "L:${loToday}° ~ H:${hiToday}°")
                        }

                        val nameIds = intArrayOf(R.id.d1_name, R.id.d2_name, R.id.d3_name)
                        val iconIds = intArrayOf(R.id.d1_icon, R.id.d2_icon, R.id.d3_icon)
                        val tempIds = intArrayOf(R.id.d1_temps, R.id.d2_temps, R.id.d3_temps)

                        val inFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                        val outFmt = SimpleDateFormat("EEE", Locale.US)

                        for (idx in 0..2) {
                            val dayIdx = idx + 1
                            if (dayIdx < times.length()) {
                                val dDate: Date? = inFmt.parse(times.getString(dayIdx))
                                val dayLabel = if (dDate != null) outFmt.format(dDate).uppercase(Locale.US) else "---"
                                val dW = mapWeatherCode(codes.getInt(dayIdx), true)
                                val dMin = formatTemp(minArr.getDouble(dayIdx), useF)
                                val dMax = formatTemp(maxArr.getDouble(dayIdx), useF)

                                views.setTextViewText(nameIds[idx], dayLabel)
                                views.setImageViewResource(iconIds[idx], dW.iconRes)
                                views.setTextViewText(tempIds[idx], "$dMin/$dMax°")
                            }
                        }
                    }
                } catch (_: Exception) {
                }
            }

            if (Prefs.isTransparent(context)) {
                views.setInt(R.id.widget_root, "setBackgroundResource", R.drawable.widget_bg_transparent)
            } else {
                views.setInt(R.id.widget_root, "setBackgroundResource", bgRes)
            }

            manager.updateAppWidget(appWidgetId, views)
        }

        private fun formatTemp(c: Double, fahrenheit: Boolean): Int {
            val v = if (fahrenheit) (c * 9.0 / 5.0) + 32.0 else c
            return v.roundToInt()
        }

        private data class WeatherVisual(val label: String, val iconRes: Int, val bgRes: Int)

        private fun mapWeatherCode(code: Int, isDay: Boolean): WeatherVisual {
            return when (code) {
                0 -> WeatherVisual(
                    "Clear",
                    if (isDay) R.drawable.ic_weather_clear_day else R.drawable.ic_weather_clear_night,
                    if (isDay) R.drawable.widget_bg_blue else R.drawable.widget_bg_night
                )
                1 -> WeatherVisual(
                    "Mainly Clear",
                    if (isDay) R.drawable.ic_weather_clear_day else R.drawable.ic_weather_clear_night,
                    if (isDay) R.drawable.widget_bg_blue else R.drawable.widget_bg_night
                )
                2 -> WeatherVisual(
                    "Partly Cloudy",
                    if (isDay) R.drawable.ic_weather_partly_cloudy_day else R.drawable.ic_weather_partly_cloudy_night,
                    if (isDay) R.drawable.widget_bg_blue else R.drawable.widget_bg_night
                )
                3 -> WeatherVisual(
                    "Cloudy",
                    R.drawable.ic_weather_cloudy,
                    if (isDay) R.drawable.widget_bg_blue else R.drawable.widget_bg_night
                )
                45, 48 -> WeatherVisual("Foggy", R.drawable.ic_weather_fog, R.drawable.widget_bg_blue)
                51, 53, 55, 56, 57 -> WeatherVisual("Drizzle", R.drawable.ic_weather_rain, R.drawable.widget_bg_rain)
                61, 63, 65, 66, 67, 80, 81, 82 -> WeatherVisual("Rain", R.drawable.ic_weather_rain, R.drawable.widget_bg_rain)
                71, 73, 75, 77, 85, 86 -> WeatherVisual("Snow", R.drawable.ic_weather_snow, R.drawable.widget_bg_rain)
                95, 96, 99 -> WeatherVisual("Storm", R.drawable.ic_weather_storm, R.drawable.widget_bg_rain)
                else -> WeatherVisual(
                    "Clear",
                    if (isDay) R.drawable.ic_weather_clear_day else R.drawable.ic_weather_clear_night,
                    R.drawable.widget_bg_blue
                )
            }
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        updateAllWidgets(context, fetchNetwork = true)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_REFRESH,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> updateAllWidgets(context, fetchNetwork = true)
        }
    }
}

class WeatherWidgetProvider1x1 : WeatherWidgetProvider()
class WeatherWidgetProvider2x2 : WeatherWidgetProvider()
class WeatherWidgetProvider4x4 : WeatherWidgetProvider()
