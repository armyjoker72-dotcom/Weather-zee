package com.zahid.weatherwidget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.res.ResourcesCompat
import com.google.android.material.switchmaterial.SwitchMaterial
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private val executor = Executors.newSingleThreadExecutor()

    private val presetColors = intArrayOf(
        0xFFFFFFFF.toInt(), // White
        0xFFE0F2FE.toInt(), // Ice Blue
        0xFFFACC15.toInt(), // Gold Yellow
        0xFF38BDF8.toInt(), // Sky Cyan
        0xFF4ADE80.toInt(), // Mint Green
        0xFFFB923C.toInt(), // Orange
        0xFFF87171.toInt(), // Coral Red
        0xFFF472B6.toInt(), // Pink
        0xFFC084FC.toInt(), // Purple
        0xFFCBD5E1.toInt(), // Silver Grey
        0xFF1E3A8A.toInt(), // Deep Blue
        0xFF000000.toInt()  // Black
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnPin = findViewById<Button>(R.id.btnPinWidget)
        val btnRefresh = findViewById<Button>(R.id.btnRefreshNow)
        val tvCurrentCity = findViewById<TextView>(R.id.tvCurrentCity)
        val etCitySearch = findViewById<EditText>(R.id.etCitySearch)
        val btnSearchCity = findViewById<Button>(R.id.btnSearchCity)
        val tvCityStatus = findViewById<TextView>(R.id.tvCityStatus)
        val swTransparent = findViewById<SwitchMaterial>(R.id.swTransparent)
        val swHour12 = findViewById<SwitchMaterial>(R.id.swHour12)
        val swFahrenheit = findViewById<SwitchMaterial>(R.id.swFahrenheit)
        val spClockFont = findViewById<Spinner>(R.id.spClockFont)
        val tvFontPreview = findViewById<TextView>(R.id.tvFontPreview)
        val swBorderEnabled = findViewById<SwitchMaterial>(R.id.swBorderEnabled)
        val swTop3D = findViewById<SwitchMaterial>(R.id.swTop3D)
        val btnReset = findViewById<Button>(R.id.btnResetAppearance)

        fun updateCityLabel() {
            val c = Prefs.getCity(this)
            val country = Prefs.getCountry(this)
            tvCurrentCity.text = if (country.isNotBlank()) "$c, $country" else c
        }

        fun updateClockPreviewStyle() {
            val pos = Prefs.getFontIndex(this)
            tvFontPreview.typeface = ResourcesCompat.getFont(this, Prefs.FONT_RES_IDS[pos])
            tvFontPreview.setTextColor(Prefs.getClockColor(this))
            val bCol = Prefs.getClockBorderColor(this)
            if (Prefs.is3DFont(pos)) {
                tvFontPreview.setShadowLayer(6f, 8f, 8f, bCol)
            } else if (Prefs.isBorderEnabled(this)) {
                tvFontPreview.setShadowLayer(4f, 0f, 0f, bCol)
            } else {
                tvFontPreview.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
            }
        }

        updateCityLabel()

        btnPin.setOnClickListener {
            val mgr = AppWidgetManager.getInstance(this)
            val provider = ComponentName(this, WeatherWidgetProvider::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(provider, null, null)
            } else {
                Toast.makeText(
                    this,
                    "Long-press your Home Screen -> Widgets -> Zahid Weather & Clock",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        btnRefresh.setOnClickListener {
            WeatherWidgetProvider.updateAllWidgets(this, fetchNetwork = true)
            Toast.makeText(this, "Refreshing live weather...", Toast.LENGTH_SHORT).show()
        }

        btnSearchCity.setOnClickListener {
            val query = etCitySearch.text.toString().trim()
            if (query.length < 2) {
                tvCityStatus.text = "Please type a valid city name."
                return@setOnClickListener
            }
            tvCityStatus.text = "Searching $query..."
            executor.execute {
                try {
                    val encoded = URLEncoder.encode(query, "UTF-8")
                    val url = "https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=en&format=json"
                    val conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = 8000
                    conn.readTimeout = 8000
                    val text = BufferedReader(InputStreamReader(conn.inputStream)).use { it.readText() }
                    conn.disconnect()

                    val json = JSONObject(text)
                    val results = json.optJSONArray("results")
                    if (results != null && results.length() > 0) {
                        val first = results.getJSONObject(0)
                        val name = first.getString("name")
                        val country = first.optString("country", "")
                        val lat = first.getDouble("latitude")
                        val lon = first.getDouble("longitude")
                        Prefs.setCity(this, name, country, lat, lon)
                        runOnUiThread {
                            updateCityLabel()
                            etCitySearch.setText("")
                            tvCityStatus.text = "City set to $name!"
                            WeatherWidgetProvider.updateAllWidgets(this, fetchNetwork = true)
                        }
                    } else {
                        runOnUiThread { tvCityStatus.text = "City not found. Try another spelling." }
                    }
                } catch (_: Exception) {
                    runOnUiThread { tvCityStatus.text = "Network error. Check internet connection." }
                }
            }
        }

        // Appearance Switches
        swTransparent.isChecked = Prefs.isTransparent(this)
        swTransparent.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setTransparent(this, isChecked)
            WeatherWidgetProvider.updateAllWidgets(this, fetchNetwork = false)
        }

        swHour12.isChecked = Prefs.isHour12(this)
        swHour12.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setHour12(this, isChecked)
            WeatherWidgetProvider.updateAllWidgets(this, fetchNetwork = false)
        }

        swFahrenheit.isChecked = Prefs.isFahrenheit(this)
        swFahrenheit.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setFahrenheit(this, isChecked)
            WeatherWidgetProvider.updateAllWidgets(this, fetchNetwork = false)
        }

        swBorderEnabled.isChecked = Prefs.isBorderEnabled(this)
        swBorderEnabled.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setBorderEnabled(this, isChecked)
            updateClockPreviewStyle()
            WeatherWidgetProvider.updateAllWidgets(this, fetchNetwork = false)
        }

        swTop3D.isChecked = Prefs.isTop3DEnabled(this)
        swTop3D.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setTop3DEnabled(this, isChecked)
            WeatherWidgetProvider.updateAllWidgets(this, fetchNetwork = false)
        }

        // 20 Clock Fonts Spinner (15 Classic/Modern + 5 3D Fonts)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Prefs.FONT_LABELS)
        spClockFont.adapter = adapter
        spClockFont.setSelection(Prefs.getFontIndex(this))
        updateClockPreviewStyle()

        spClockFont.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                Prefs.setFontIndex(this@MainActivity, position)
                updateClockPreviewStyle()
                WeatherWidgetProvider.updateAllWidgets(this@MainActivity, fetchNetwork = false)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Size & Border Thickness Controls
        val refreshSizeUI = mutableListOf<() -> Unit>()

        fun bindSizeControl(
            tvId: Int,
            sbId: Int,
            minusId: Int,
            plusId: Int,
            label: String,
            unit: String,
            minVal: Int,
            maxVal: Int,
            getter: () -> Float,
            setter: (Float) -> Unit
        ) {
            val tv = findViewById<TextView>(tvId)
            val sb = findViewById<SeekBar>(sbId)
            val btnMinus = findViewById<Button>(minusId)
            val btnPlus = findViewById<Button>(plusId)

            sb.max = maxVal - minVal

            fun syncView() {
                val cur = getter().roundToInt().coerceIn(minVal, maxVal)
                tv.text = "$label: $cur $unit"
                sb.progress = cur - minVal
            }

            syncView()
            refreshSizeUI.add { syncView() }

            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = minVal + progress
                    tv.text = "$label: $value $unit"
                    if (fromUser) {
                        setter(value.toFloat())
                        WeatherWidgetProvider.updateAllWidgets(this@MainActivity, fetchNetwork = false)
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })

            btnMinus.setOnClickListener {
                val next = (getter().roundToInt() - 1).coerceIn(minVal, maxVal)
                setter(next.toFloat())
                syncView()
                WeatherWidgetProvider.updateAllWidgets(this@MainActivity, fetchNetwork = false)
            }

            btnPlus.setOnClickListener {
                val next = (getter().roundToInt() + 1).coerceIn(minVal, maxVal)
                setter(next.toFloat())
                syncView()
                WeatherWidgetProvider.updateAllWidgets(this@MainActivity, fetchNetwork = false)
            }
        }

        bindSizeControl(R.id.tvSizeDate, R.id.sbDate, R.id.btnMinusDate, R.id.btnPlusDate,
            "Date Size", "sp", 10, 26, { Prefs.getDateSize(this) }, { Prefs.setDateSize(this, it) })
        bindSizeControl(R.id.tvSizeDay, R.id.sbDay, R.id.btnMinusDay, R.id.btnPlusDay,
            "Day Size", "sp", 10, 24, { Prefs.getDaySize(this) }, { Prefs.setDaySize(this, it) })
        bindSizeControl(R.id.tvSizeClock, R.id.sbClock, R.id.btnMinusClock, R.id.btnPlusClock,
            "Clock Time Size", "sp", 26, 66, { Prefs.getClockSize(this) }, { Prefs.setClockSize(this, it) })
        bindSizeControl(R.id.tvSizeCity, R.id.sbCity, R.id.btnMinusCity, R.id.btnPlusCity,
            "Location (City) Size", "sp", 10, 26, { Prefs.getCitySize(this) }, { Prefs.setCitySize(this, it) })
        bindSizeControl(R.id.tvSizeWeather, R.id.sbWeather, R.id.btnMinusWeather, R.id.btnPlusWeather,
            "Live Weather Size", "sp", 24, 58, { Prefs.getWeatherSize(this) }, { Prefs.setWeatherSize(this, it) })
        bindSizeControl(R.id.tvSizeForecast, R.id.sbForecast, R.id.btnMinusForecast, R.id.btnPlusForecast,
            "3-Day Forecast Size", "sp", 9, 22, { Prefs.getForecastSize(this) }, { Prefs.setForecastSize(this, it) })
        bindSizeControl(R.id.tvSizeBorderW, R.id.sbBorderW, R.id.btnMinusBorderW, R.id.btnPlusBorderW,
            "Border Thickness", "dp", 1, 6, { Prefs.getBorderWidth(this) }, { Prefs.setBorderWidth(this, it) })

        // Color Picker Controls
        val refreshColorUI = mutableListOf<() -> Unit>()

        fun applySwatch(view: View, color: Int) {
            val d = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                setStroke(3, Color.parseColor("#94A3B8"))
            }
            view.background = d
        }

        fun bindColorControl(
            btnId: Int,
            swatchId: Int,
            title: String,
            getter: () -> Int,
            setter: (Int) -> Unit,
            onApplied: (() -> Unit)? = null
        ) {
            val btn = findViewById<Button>(btnId)
            val swatch = findViewById<View>(swatchId)

            fun sync() = applySwatch(swatch, getter())
            sync()
            refreshColorUI.add { sync() }

            val openPicker = View.OnClickListener {
                showColorPickerDialog(title, getter()) { chosen ->
                    setter(chosen)
                    sync()
                    onApplied?.invoke()
                    WeatherWidgetProvider.updateAllWidgets(this@MainActivity, fetchNetwork = false)
                }
            }
            btn.setOnClickListener(openPicker)
            swatch.setOnClickListener(openPicker)
        }

        // Top Section Fill Colors
        bindColorControl(R.id.btnColorDate, R.id.swatchDate, "Date Font Color",
            { Prefs.getDateColor(this) }, { Prefs.setDateColor(this, it) })
        bindColorControl(R.id.btnColorDay, R.id.swatchDay, "Day Font Color",
            { Prefs.getDayColor(this) }, { Prefs.setDayColor(this, it) })
        bindColorControl(R.id.btnColorClock, R.id.swatchClock, "Time (Clock) Font Color",
            { Prefs.getClockColor(this) }, { Prefs.setClockColor(this, it) },
            onApplied = { updateClockPreviewStyle() })
        bindColorControl(R.id.btnColorCity, R.id.swatchCity, "Location Font Color",
            { Prefs.getCityColor(this) }, { Prefs.setCityColor(this, it) })

        // Separate Border Colors Menu (Date, Day, Time, Location)
        bindColorControl(R.id.btnBorderDate, R.id.swatchBorderDate, "Date Border Color",
            { Prefs.getDateBorderColor(this) }, { Prefs.setDateBorderColor(this, it) })
        bindColorControl(R.id.btnBorderDay, R.id.swatchBorderDay, "Day Border Color",
            { Prefs.getDayBorderColor(this) }, { Prefs.setDayBorderColor(this, it) })
        bindColorControl(R.id.btnBorderClock, R.id.swatchBorderClock, "Time (Clock) Border Color",
            { Prefs.getClockBorderColor(this) }, { Prefs.setClockBorderColor(this, it) },
            onApplied = { updateClockPreviewStyle() })
        bindColorControl(R.id.btnBorderCity, R.id.swatchBorderCity, "Location Border Color",
            { Prefs.getCityBorderColor(this) }, { Prefs.setCityBorderColor(this, it) })

        // Live Weather Color
        bindColorControl(R.id.btnColorWeather, R.id.swatchWeather, "Live Weather Color",
            { Prefs.getWeatherColor(this) }, { Prefs.setWeatherColor(this, it) })

        // 3-Day Forecast Color
        bindColorControl(R.id.btnColorForecast, R.id.swatchForecast, "3-Day Forecast Color",
            { Prefs.getForecastColor(this) }, { Prefs.setForecastColor(this, it) })

        // Reset All
        btnReset.setOnClickListener {
            Prefs.resetAppearance(this)
            swBorderEnabled.isChecked = Prefs.isBorderEnabled(this)
            swTop3D.isChecked = Prefs.isTop3DEnabled(this)
            refreshSizeUI.forEach { it() }
            refreshColorUI.forEach { it() }
            updateClockPreviewStyle()
            WeatherWidgetProvider.updateAllWidgets(this, fetchNetwork = false)
            Toast.makeText(this, "Sizes, colors & borders reset to default", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showColorPickerDialog(title: String, initialColor: Int, onColorPicked: (Int) -> Unit) {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).roundToInt()

        var r = Color.red(initialColor)
        var g = Color.green(initialColor)
        var b = Color.blue(initialColor)

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(8))
        }

        val preview = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 15f
            setPadding(dp(12), dp(16), dp(12), dp(16))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(14) }
        }
        container.addView(preview)

        lateinit var sbR: SeekBar
        lateinit var sbG: SeekBar
        lateinit var sbB: SeekBar
        lateinit var tvR: TextView
        lateinit var tvG: TextView
        lateinit var tvB: TextView

        fun updatePreview() {
            val c = Color.rgb(r, g, b)
            val bg = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(c)
                setStroke(dp(1), Color.GRAY)
            }
            preview.background = bg
            preview.text = String.format("#%02X%02X%02X", r, g, b)
            val luminance = 0.299 * r + 0.587 * g + 0.114 * b
            preview.setTextColor(if (luminance > 140) Color.BLACK else Color.WHITE)
            tvR.text = "Red: $r"
            tvG.text = "Green: $g"
            tvB.text = "Blue: $b"
        }

        for (rowIdx in 0..1) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(10) }
            }
            for (colIdx in 0..5) {
                val col = presetColors[rowIdx * 6 + colIdx]
                val swatch = View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply {
                        marginEnd = if (colIdx < 5) dp(8) else 0
                    }
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(col)
                        setStroke(dp(2), Color.parseColor("#94A3B8"))
                    }
                    setOnClickListener {
                        r = Color.red(col)
                        g = Color.green(col)
                        b = Color.blue(col)
                        sbR.progress = r
                        sbG.progress = g
                        sbB.progress = b
                        updatePreview()
                    }
                }
                row.addView(swatch)
            }
            container.addView(row)
        }

        fun addRgbSlider(labelText: String, initVal: Int, onChange: (Int) -> Unit): Pair<TextView, SeekBar> {
            val tv = TextView(this).apply {
                text = "$labelText: $initVal"
                textSize = 13f
            }
            val sb = SeekBar(this).apply {
                max = 255
                progress = initVal
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(6) }
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        if (fromUser) {
                            onChange(progress)
                            updatePreview()
                        }
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            }
            container.addView(tv)
            container.addView(sb)
            return Pair(tv, sb)
        }

        val pR = addRgbSlider("Red", r) { r = it }
        val pG = addRgbSlider("Green", g) { g = it }
        val pB = addRgbSlider("Blue", b) { b = it }
        tvR = pR.first; sbR = pR.second
        tvG = pG.first; sbG = pG.second
        tvB = pB.first; sbB = pB.second

        updatePreview()

        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(container)
            .setPositiveButton("Apply Color") { _, _ ->
                onColorPicked(Color.rgb(r, g, b))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
